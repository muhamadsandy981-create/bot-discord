require('dotenv').config();
const fs = require('fs');
const {
    Client,
    GatewayIntentBits,
    PermissionsBitField,
    ActivityType,
    ChannelType,
    EmbedBuilder,
    AttachmentBuilder,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    StringSelectMenuBuilder,
    UserSelectMenuBuilder,
    ModalBuilder,
    TextInputBuilder,
    TextInputStyle
} = require('discord.js');
const { buatGambarWelcome } = require('./welcome-image');

// ==========================================
// PENGATURAN BOT DISCORD
// ==========================================
const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildVoiceStates,
        GatewayIntentBits.GuildMembers
    ]
});

const PREFIX = 'ltn ';
const THEME_COLOR = '#fd4ddf';
const SUCCESS_COLOR = '#2ecc71';
const ERROR_COLOR = '#e74c3c';
const PATH_FILTER = './bad_words.json';
const PATH_UANG = './uang.json';
const PATH_OWO_STATE = './owo_state.json';
const PATH_MOD_LOG = './mod_log.json';
const PATH_ADMIN_LOGS = './admin_logs.json';
const PATH_ADMIN_SCHEDULES = './admin_schedules.json';
const PATH_ADMIN_BACKUPS = './admin_backups.json';
const COOLDOWN_HARIAN = 24 * 60 * 60 * 1000;
const formatUang = jumlah => new Intl.NumberFormat('id-ID').format(jumlah);
const jeda = durasi => new Promise(resolve => setTimeout(resolve, durasi));

if (!fs.existsSync(PATH_UANG)) fs.writeFileSync(PATH_UANG, JSON.stringify({}));
const economyData = JSON.parse(fs.readFileSync(PATH_UANG, 'utf8'));
if (!economyData || typeof economyData !== 'object' || Array.isArray(economyData)) {
    throw new Error('Isi uang.json harus berupa objek saldo pengguna.');
}
if (!economyData.servers || typeof economyData.servers !== 'object' || Array.isArray(economyData.servers)) {
    const saldoLama = Object.fromEntries(
        Object.entries(economyData).filter(([id, saldo]) => /^\d{17,20}$/.test(id) && Number.isSafeInteger(saldo) && saldo >= 0)
    );
    for (const key of Object.keys(economyData)) delete economyData[key];
    economyData.servers = {};
    economyData.legacyBalances = saldoLama;
}

if (!fs.existsSync(PATH_OWO_STATE)) fs.writeFileSync(PATH_OWO_STATE, JSON.stringify({}));
const owoState = JSON.parse(fs.readFileSync(PATH_OWO_STATE, 'utf8'));
if (!owoState || typeof owoState !== 'object' || Array.isArray(owoState)) {
    throw new Error('Isi owo_state.json harus berupa objek data pengguna.');
}
if (!owoState.servers || typeof owoState.servers !== 'object' || Array.isArray(owoState.servers)) {
    const dataLama = Object.fromEntries(
        Object.entries(owoState).filter(([id, data]) => /^\d{17,20}$/.test(id) && data && typeof data === 'object')
    );
    for (const key of Object.keys(owoState)) delete owoState[key];
    owoState.servers = {};
    owoState.legacyUsers = dataLama;
}

if (!fs.existsSync(PATH_MOD_LOG)) fs.writeFileSync(PATH_MOD_LOG, JSON.stringify({}));
const modLogConfig = JSON.parse(fs.readFileSync(PATH_MOD_LOG, 'utf8'));
if (!modLogConfig || typeof modLogConfig !== 'object' || Array.isArray(modLogConfig)) {
    throw new Error('Isi mod_log.json harus berupa objek pengaturan log moderasi.');
}

function muatObjekJson(path, deskripsi) {
    if (!fs.existsSync(path)) fs.writeFileSync(path, JSON.stringify({}, null, 2));
    const data = JSON.parse(fs.readFileSync(path, 'utf8'));
    if (!data || typeof data !== 'object' || Array.isArray(data)) {
        throw new Error(`Isi ${path} harus berupa objek ${deskripsi}.`);
    }
    return data;
}

const adminLogs = muatObjekJson(PATH_ADMIN_LOGS, 'log moderasi');
const adminSchedules = muatObjekJson(PATH_ADMIN_SCHEDULES, 'jadwal pengumuman');
const adminBackups = muatObjekJson(PATH_ADMIN_BACKUPS, 'backup konfigurasi');
const scheduleTimers = new Map();

function simpanUang() {
    fs.writeFileSync(PATH_UANG, JSON.stringify(economyData, null, 2));
}

function simpanOwoState() {
    fs.writeFileSync(PATH_OWO_STATE, JSON.stringify(owoState, null, 2));
}

function simpanAdminLogs() {
    fs.writeFileSync(PATH_ADMIN_LOGS, JSON.stringify(adminLogs, null, 2));
}

function simpanAdminSchedules() {
    fs.writeFileSync(PATH_ADMIN_SCHEDULES, JSON.stringify(adminSchedules, null, 2));
}

function simpanAdminBackups() {
    fs.writeFileSync(PATH_ADMIN_BACKUPS, JSON.stringify(adminBackups, null, 2));
}

function ambilDataServer(guildId) {
    if (!economyData.servers[guildId]) economyData.servers[guildId] = {};
    if (!owoState.servers[guildId]) owoState.servers[guildId] = { users: {}, settings: {}, filter: { words: [], ignoredChannels: [], ignoredRoles: [] } };
    const server = owoState.servers[guildId];
    if (!server.users || typeof server.users !== 'object' || Array.isArray(server.users)) server.users = {};
    if (!server.settings || typeof server.settings !== 'object' || Array.isArray(server.settings)) server.settings = {};
    if (!server.filter || typeof server.filter !== 'object' || Array.isArray(server.filter)) server.filter = {};
    if (!Array.isArray(server.filter.words)) server.filter.words = [];
    if (!Array.isArray(server.filter.ignoredChannels)) server.filter.ignoredChannels = [];
    if (!Array.isArray(server.filter.ignoredRoles)) server.filter.ignoredRoles = [];
    if (!server.voice || typeof server.voice !== 'object' || Array.isArray(server.voice)) server.voice = {};
    if (!server.voice.rooms || typeof server.voice.rooms !== 'object' || Array.isArray(server.voice.rooms)) server.voice.rooms = {};
    if (Object.prototype.hasOwnProperty.call(server.voice, 'connection')) {
        delete server.voice.connection;
        simpanOwoState();
    }
    if (!server.settings || typeof server.settings !== 'object' || Array.isArray(server.settings)) server.settings = {};
    if (!Number.isSafeInteger(server.settings.dailyReward) || server.settings.dailyReward < 0) server.settings.dailyReward = 1000;
    if (!Number.isSafeInteger(server.settings.startingBalance) || server.settings.startingBalance < 0) server.settings.startingBalance = 500;
    const saldoLegacy = economyData.legacyBalances;
    if (saldoLegacy && typeof saldoLegacy === 'object') {
        Object.assign(economyData.servers[guildId], saldoLegacy);
        delete economyData.legacyBalances;
        simpanUang();
    }
    const userLegacy = owoState.legacyUsers;
    if (userLegacy && typeof userLegacy === 'object') {
        Object.assign(server.users, userLegacy);
        delete owoState.legacyUsers;
        simpanOwoState();
    }
    return server;
}

const voiceCreationLocks = new Set();

const voicePanelActions = [
    ['name', 'NAME', '🏷️'],
    ['limit', 'LIMIT', '👥'],
    ['privacy', 'PRIVACY', '🛡️'],
    ['trust', 'TRUST', '🟢'],
    ['untrust', 'UNTRUST', '🎙️'],
    ['invite', 'INVITE', '📞'],
    ['kick', 'KICK', '📵'],
    ['block', 'BLOCK', '🚫'],
    ['unblock', 'UNBLOCK', '🔓'],
    ['info', 'INFO', 'ℹ️'],
    ['log', 'LOG', '🗒️'],
    ['claim', 'CLAIM', '👑'],
    ['transfer', 'TRANSFER', '🔁'],
    ['reset', 'RESET', '⚙️'],
    ['delete', 'DELETE', '🗑️']
];

function buatBarisTombolPanelVoice(customId) {
    const rows = [];
    for (let index = 0; index < voicePanelActions.length; index += 5) {
        rows.push(new ActionRowBuilder().addComponents(
            ...voicePanelActions.slice(index, index + 5).map(([action, label, emoji]) =>
                new ButtonBuilder()
                    .setCustomId(customId(action))
                    .setLabel(label)
                    .setEmoji(emoji)
                    .setStyle(action === 'delete' ? ButtonStyle.Danger : ButtonStyle.Secondary)
            )
        ));
    }
    return rows;
}

function buatPanelVoice(room, ownerId) {
    const embed = new EmbedBuilder()
        .setColor(THEME_COLOR)
        .setTitle('Voice Control Interface')
        .setDescription('Kelola voice sementara Anda menggunakan tombol di bawah ini.\n' +
            `Channel: **${room.name}** • Pemilik: <@${ownerId}>\n` +
            'Untuk aksi anggota, cari nama lalu pilih dari menu Discord.');
    return {
        embeds: [embed],
        components: buatBarisTombolPanelVoice(action => `tempvoice:${action}:${room.id}`)
    };
}

function buatPanelVoiceBersama(guildId) {
    const embed = new EmbedBuilder()
        .setColor(THEME_COLOR)
        .setTitle('Voice Control Interface')
        .setDescription('Kelola voice sementara Anda menggunakan tombol di bawah ini.');
    return {
        embeds: [embed],
        components: buatBarisTombolPanelVoice(action => `tempvoice-shared:${action}:${guildId}`)
    };
}

function buatMenuPilihAnggotaVoice(action, roomId, ownerId) {
    const labels = {
        trust: 'Pilih anggota untuk diberi akses',
        untrust: 'Pilih anggota untuk mencabut akses',
        invite: 'Pilih anggota untuk diundang',
        kick: 'Pilih anggota yang akan dikeluarkan',
        block: 'Pilih anggota yang akan diblokir',
        unblock: 'Pilih anggota untuk membuka blokir',
        transfer: 'Pilih pemilik voice yang baru'
    };
    const menu = new UserSelectMenuBuilder()
        .setCustomId(`tempvoice-user:${action}:${roomId}:${ownerId}`)
        .setPlaceholder(labels[action] || 'Cari anggota berdasarkan nama')
        .setMinValues(1)
        .setMaxValues(1);
    if (action === 'kick' || action === 'transfer') {
        menu.setPlaceholder(`${labels[action]} • harus sedang di voice`);
    }
    return new ActionRowBuilder().addComponents(menu);
}

function catatAksiPanelVoice(guildId, room, user, aksi) {
    catatLogMod(guildId, `🔊 [VOICE PANEL] ${user.tag} ${aksi} di ${room.name} (${room.id}).`, 'voice-panel');
}

function buatEmbedLogVoice(member, event) {
    const bergabung = event === 'join';
    return new EmbedBuilder()
        .setColor(bergabung ? SUCCESS_COLOR : ERROR_COLOR)
        .setDescription(`${member} ${bergabung ? 'joined the voice channels.' : 'left the voice channel.'}`);
}

async function jalankanAksiAnggotaVoice(interaction, room, action, targetId, server, ownerId) {
    const reply = options => interaction.isUserSelectMenu()
        ? interaction.followUp({ ...options, ephemeral: true })
        : interaction.reply({ ...options, ephemeral: true });
    const target = await interaction.guild.members.fetch(targetId).catch(error => {
        console.error('Gagal mencari anggota untuk pengaturan voice:', error);
        return null;
    });
    if (!target || target.user.bot || target.id === ownerId) {
        await reply({ content: 'Anggota tidak valid atau merupakan pemilik channel.' });
        return;
    }
    if ((action === 'transfer' || action === 'kick') && target.voice.channelId !== room.id) {
        await reply({ content: 'Untuk aksi ini, anggota harus sedang berada di room voice yang sama.' });
        return;
    }
    if (action === 'kick') {
        await target.voice.disconnect('Dikeluarkan oleh pemilik voice sementara');
        catatAksiPanelVoice(interaction.guild.id, room, interaction.user, `mengeluarkan ${target.user.tag}`);
        await reply({ content: `👢 ${target.user.tag} dikeluarkan dari room.` });
        return;
    }
    if (action === 'trust' || action === 'invite' || action === 'untrust' || action === 'block' || action === 'unblock') {
        if (action === 'untrust' || action === 'unblock') {
            await room.permissionOverwrites.delete(target.id);
            catatAksiPanelVoice(interaction.guild.id, room, interaction.user, `mencabut akses ${target.user.tag}`);
            await reply({ content: `✅ Izin khusus ${target.user.tag} dihapus.` });
            return;
        }
        await room.permissionOverwrites.edit(target.id, action === 'block'
            ? { ViewChannel: false, Connect: false }
            : { ViewChannel: true, Connect: true, Speak: true });
        catatAksiPanelVoice(
            interaction.guild.id,
            room,
            interaction.user,
            `${action === 'block' ? 'memblokir' : action === 'trust' ? 'memberi trust kepada' : 'mengundang'} ${target.user.tag}`
        );
        await reply({
            content: action === 'block'
                ? `⛔ ${target.user.tag} diblokir dari room.`
                : `✅ ${target.user.tag} sekarang dapat melihat dan masuk ke room.`
        });
        return;
    }
    if (action === 'transfer') {
        await room.permissionOverwrites.edit(target.id, { ViewChannel: true, Connect: true, Speak: true });
        await room.permissionOverwrites.edit(ownerId, { ViewChannel: null, Connect: null, Speak: null });
        server.voice.rooms[room.id] = target.id;
        simpanOwoState();
        catatAksiPanelVoice(interaction.guild.id, room, interaction.user, `mentransfer kepemilikan kepada ${target.user.tag}`);
        await reply({ content: `👑 Kepemilikan room dipindahkan ke ${target}.` });
        return;
    }
    await interaction.reply({ content: 'Aksi anggota voice tidak dikenal.', ephemeral: true });
}

const kategoriHelpPublik = {
    ringkasan: {
        judul: '📘 Panduan Singkat',
        isi: 'Pilih kategori dari menu dropdown di bawah untuk melihat panduan command.\n\n' +
            '**Cara memakai command**\n' +
            '• Semua command diawali `ltn ` (huruf kecil dan diakhiri spasi).\n' +
            '• Ganti teks dalam `<...>` dengan nilai yang diminta; bagian `[...]` bersifat opsional.\n' +
            '• Mention anggota, role, atau channel dengan memilihnya dari Discord.\n\n' +
            '**Contoh**\n' +
            '`ltn cash` untuk cek saldo • `ltn send @teman 1.000` untuk transfer.\n' +
            'Gunakan menu kategori untuk melihat fitur ekonomi, game, voice, dan profil.'
    },
    voice: {
        judul: '🔊 Voice Sementara',
        isi: 'Masuk ke lobby voice yang disiapkan server untuk membuat room sementara. Panel kontrol tersedia di chat voice.\n' +
            '`ltn vc panel` — munculkan kembali panel saat berada di voice sementara milikmu.\n' +
            '`ltn vc panel #channel` — admin mengirim atau memperbarui panel bersama di channel teks.\n' +
            '`ltn vc owner` — lihat pemilik voice yang sedang kamu masuki.\n' +
            '`ltn vc lock` / `ltn vc unlock` — kunci/buka voice milikmu.\n' +
            '`ltn vc limit <0-99>` — atur batas anggota; 0 berarti tanpa batas.\n' +
            '`ltn vc name <nama>` — ganti nama voice.\n' +
            '`ltn vc transfer @anggota` / `ltn vc kick @anggota` — atau pilih anggota lewat menu pencarian di panel.\n\n' +
            'Panel juga menyediakan privasi, trust/invite, block, claim, dan hapus. Aksi anggota pada panel bisa dicari berdasarkan nama.'
    },
    ekonomi: {
        judul: '💰 Ekonomi & Koleksi',
        isi: '`ltn cash` / `ltn bal` — cek saldo koin. `ltn daily` — klaim hadiah harian.\n' +
            '`ltn top` — leaderboard • `ltn profil` — dashboard privat saldo, level, daily, zoo, inventory, transfer, dan toko; `ltn profile @anggota` — lihat profil publik.\n' +
            '`ltn history [@anggota]` — riwayat transaksi dan permainan.\n' +
            '`ltn send @anggota <jumlah/all>` — transfer koin; contoh `1.000`.\n' +
            '`ltn pray @anggota` / `ltn curse @anggota` — aksi dengan cooldown.\n' +
            '`ltn shop` / `ltn buy <barang> [jumlah]` / `ltn inventory`.\n' +
            '`ltn use umpan` — gunakan umpan • `ltn hunt` — berburu hewan.\n' +
            '`ltn zoo` — lihat koleksi • `ltn sell all` — jual hasil buruan.'
    },
    game: {
        judul: '🎮 Mini-Game',
        isi: '`ltn cf <head/tail> <jumlah/all>` — tebak sisi koin.\n' +
            '`ltn slot <jumlah/all>` — animal slot.\n' +
            '`ltn mines <jumlah/all> [bom 1-8]` — mines interaktif dengan cash out.\n' +
            '`ltn gamble <jumlah/all>` — adu angka dadu 0–100.\n\n' +
            'Permainan juga bisa dimulai dari **Dashboard → Main Game**. Hunt memiliki cooldown 60 detik; game taruhan memiliki cooldown 10 detik per jenis. Jumlah taruhan menerima titik ribuan (`1.000.000`) atau `all`.'
    }
};

const kategoriHelpAdmin = {
    moderasi: {
        judul: '🛡️ Moderasi',
        isi: '`ltn kick @anggota` — keluarkan anggota (Kick Members).\n' +
            '`ltn clear <1-100>` — hapus pesan (Manage Messages).\n' +
            '`ltn timeout @anggota <durasi> [alasan]` — contoh `30m`, `2h` (Moderate Members).\n' +
            '`ltn slowmode [#channel] <detik>` — atur 0–21600 detik (Manage Channels).\n' +
            '`ltn lock [#channel]` / `ltn unlock [#channel]` — kunci/buka channel (Manage Channels).\n' +
            '`ltn filter tambah/hapus/daftar <kata>` — kelola filter (Manage Messages).\n' +
            '`ltn filter ignore-channel #channel` / `unignore-channel #channel`.\n' +
            '`ltn filter ignore-role @role` / `unignore-role @role`.\n' +
            '`ltn modlog set #channel` / `ltn modlog off` — atur log moderasi.\n' +
            '`ltn modsummary [24h/7d] [kategori]` — ringkasan tindakan moderasi.\n' +
            '`ltn mutevc` / `ltn unmutevc` / `ltn dc @anggota` — aksi moderator pada voice.'
    },
    pengaturan: {
        judul: '⚙️ Admin & Komunitas',
        isi: '`ltn welcome set #channel [pesan]` / `ltn welcome pesan <pesan>` / `ltn welcome off`.\n' +
            '`ltn goodbye set #channel [pesan]` / `ltn goodbye pesan <pesan>` / `ltn goodbye off`.\n' +
            'Kartu welcome/goodbye memakai banner LTN, avatar, username, dan jumlah anggota. Placeholder pesan: `{user}`, `{username}`, `{server}`, `{memberCount}`.\n' +
            '`ltn autorole set @role` / `ltn autorole off`.\n' +
            '`ltn verify setup #channel @role` • `ltn reportpanel [#channel]` • `ltn adminpanel [#channel]`.\n' +
            '`ltn announce #channel <pesan>` / `ltn announce jadwal #channel <durasi> <pesan>`.\n' +
            '`ltn backup buat` / `daftar` / `pulihkan <id>`.\n' +
            '`ltn economy set daily <jumlah>` / `ltn economy set start <jumlah>`.\n' +
            '`ltn autorespon tambah <kata> | <balasan>` — contoh: `ltn autorespon tambah hi | hallo!`.\n' +
            '`ltn autorespon hapus <kata>` • `ltn autorespon daftar` • `ltn autorespon aktif` / `ltn autorespon nonaktif`.\n\n' +
            'Pemicu dicocokkan dengan seluruh isi pesan. Pengaturan ini memerlukan izin **Manage Server**. Welcome, goodbye, dan auto-role juga memerlukan Server Members Intent serta izin bot yang sesuai.'
    },
    voice: {
        judul: '🔊 Konfigurasi Voice',
        isi: '`ltn vc setup #lobby` — atur lobby pembuatan voice sementara (Manage Channels).\n' +
            'Panel admin: `ltn adminpanel [#channel]`. Kepemilikan voice tetap dikelola oleh pemilik room melalui panel.\n' +
            'Aksi moderasi voice: `ltn mutevc`, `ltn unmutevc`, dan `ltn dc @anggota` sesuai izin moderator.'
    }
};

function buatHelpEmbed(kategori, adminMode = false) {
    const categories = adminMode ? kategoriHelpAdmin : kategoriHelpPublik;
    const halaman = categories[kategori] || categories.ringkasan || categories.moderasi;
    return new EmbedBuilder()
        .setColor(THEME_COLOR)
        .setTitle(`${adminMode ? '🔐 Bantuan Admin' : '📚 Bantuan Publik'} • ${halaman.judul}`)
        .setDescription(halaman.isi)
        .setFooter({ text: `${adminMode ? 'Khusus admin • ' : ''}Pilih kategori dari menu • Prefix "ltn "` })
        .setTimestamp();
}

function buatMenuHelp(userId, kategoriAktif = 'ringkasan', adminMode = false, guildId = null) {
    const labels = adminMode
        ? {
            moderasi: ['Moderasi', '🛡️ Moderasi dan izin'],
            pengaturan: ['Admin & Komunitas', '⚙️ Pengaturan server dan auto-respon'],
            voice: ['Konfigurasi Voice', '🔊 Lobby dan moderasi voice']
        }
        : {
            ringkasan: ['Panduan singkat', '📘 Cara menggunakan bot'],
            voice: ['Voice sementara', '🔊 Kelola room milikmu'],
            ekonomi: ['Ekonomi & Koleksi', '💰 Koin, profil, zoo, dan toko'],
            game: ['Mini-Game', '🎲 Permainan koin dan taruhan']
        };
    const customId = adminMode
        ? `help-select:admin:${guildId}:${userId}`
        : `help-select:public:${userId}`;
    return [new ActionRowBuilder().addComponents(
        new StringSelectMenuBuilder()
            .setCustomId(customId)
            .setPlaceholder(adminMode ? 'Pilih kategori bantuan admin' : 'Pilih kategori bantuan publik')
            .addOptions(Object.entries(labels).map(([value, [label, description]]) => ({
                label,
                value,
                description,
                emoji: description.split(' ')[0],
                default: value === kategoriAktif
            })))
    )];
}

function buatModalVoice(action, roomId) {
    const formConfig = {
        name: { title: 'Ganti nama voice', label: 'Nama channel baru', placeholder: 'Contoh: Ruang Santai', required: true, maxLength: 100 },
        limit: { title: 'Atur batas anggota', label: 'Jumlah anggota (0 = tanpa batas)', placeholder: '0 sampai 99', required: true, maxLength: 2 },
        trust: { title: 'Trust anggota', label: 'ID atau mention anggota', placeholder: '@anggota atau ID Discord', required: true, maxLength: 32 },
        untrust: { title: 'Untrust anggota', label: 'ID atau mention anggota', placeholder: '@anggota atau ID Discord', required: true, maxLength: 32 },
        invite: { title: 'Undang anggota', label: 'ID atau mention anggota', placeholder: '@anggota atau ID Discord', required: true, maxLength: 32 },
        kick: { title: 'Keluarkan anggota', label: 'ID atau mention anggota', placeholder: '@anggota atau ID Discord', required: true, maxLength: 32 },
        block: { title: 'Blokir anggota', label: 'ID atau mention anggota', placeholder: '@anggota atau ID Discord', required: true, maxLength: 32 },
        unblock: { title: 'Buka blokir anggota', label: 'ID atau mention anggota', placeholder: '@anggota atau ID Discord', required: true, maxLength: 32 },
        transfer: { title: 'Transfer kepemilikan', label: 'ID atau mention anggota di room', placeholder: '@anggota atau ID Discord', required: true, maxLength: 32 },
        delete: { title: 'Hapus voice sementara', label: 'Ketik DELETE untuk konfirmasi', placeholder: 'DELETE', required: true, maxLength: 6 },
        reset: { title: 'Reset pengaturan voice', label: 'Ketik RESET untuk menghapus izin khusus', placeholder: 'RESET', required: true, maxLength: 5 }
    };
    const config = formConfig[action];
    if (!config) return null;
    const input = new TextInputBuilder()
        .setCustomId('value')
        .setLabel(config.label)
        .setStyle(TextInputStyle.Short)
        .setPlaceholder(config.placeholder)
        .setRequired(config.required)
        .setMaxLength(config.maxLength);
    return new ModalBuilder()
        .setCustomId(`tempvoice-modal:${action}:${roomId}`)
        .setTitle(config.title)
        .addComponents(new ActionRowBuilder().addComponents(input));
}

function ambilDataPemain(server, userId, guildId) {
    const uangData = economyData.servers[guildId];
    if (!Object.prototype.hasOwnProperty.call(uangData, userId)) {
        uangData[userId] = server.settings.startingBalance;
        simpanUang();
    } else if (!Number.isSafeInteger(uangData[userId]) || uangData[userId] < 0) {
        console.error(`Saldo tidak valid untuk pengguna ${userId} di server ${guildId}; saldo diatur ke 0, bukan saldo awal.`);
        uangData[userId] = 0;
        simpanUang();
    }
    if (!server.users[userId] || typeof server.users[userId] !== 'object') server.users[userId] = {};
    const pemain = server.users[userId];
    if (!pemain.zoo || typeof pemain.zoo !== 'object' || Array.isArray(pemain.zoo)) pemain.zoo = {};
    if (!pemain.inventory || typeof pemain.inventory !== 'object' || Array.isArray(pemain.inventory)) pemain.inventory = {};
    if (!Array.isArray(pemain.history)) pemain.history = [];
    if (!pemain.stats || typeof pemain.stats !== 'object' || Array.isArray(pemain.stats)) pemain.stats = {};
    if (!Number.isSafeInteger(pemain.stats.messages) || pemain.stats.messages < 0) pemain.stats.messages = 0;
    if (!Number.isSafeInteger(pemain.stats.games) || pemain.stats.games < 0) pemain.stats.games = 0;
    if (!Number.isSafeInteger(pemain.stats.hunts) || pemain.stats.hunts < 0) pemain.stats.hunts = 0;
    if (!Number.isSafeInteger(pemain.level) || pemain.level < 0) pemain.level = 0;
    if (!Number.isSafeInteger(pemain.xp) || pemain.xp < 0) pemain.xp = 0;
    return pemain;
}

function simpanRiwayat(pemain, jenis, jumlah, detail = '') {
    pemain.history.push({ at: Date.now(), type: jenis, amount: jumlah, detail });
    if (pemain.history.length > 50) pemain.history.shift();
}

function catatLogMod(guildId, teks, type = null) {
    if (!Array.isArray(adminLogs[guildId])) adminLogs[guildId] = [];
    const match = teks.match(/(kick|timeout|clear|filter|laporan)/i);
    adminLogs[guildId].push({ at: Date.now(), type: type || match?.[1]?.toLowerCase() || 'moderasi', text: teks });
    if (adminLogs[guildId].length > 500) adminLogs[guildId].splice(0, adminLogs[guildId].length - 500);
    simpanAdminLogs();

    const channelId = modLogConfig[guildId];
    if (!channelId) return;
    const channel = client.channels.cache.get(channelId);
    if (!channel || !channel.isTextBased()) return;
    channel.send(teks).catch(error => console.error('Gagal mengirim log moderasi:', error));
}

function parseDurasi(teks) {
    const cocok = /^(\d+)(s|m|h|d)$/i.exec(teks || '');
    if (!cocok) return null;
    const faktor = { s: 1000, m: 60000, h: 3600000, d: 86400000 }[cocok[2].toLowerCase()];
    const milidetik = Number(cocok[1]) * faktor;
    return Number.isSafeInteger(milidetik) && milidetik > 0 ? milidetik : null;
}

function formatTemplate(teks, member) {
    return teks
        .replace(/\{user\}/g, `${member}`)
        .replace(/\{username\}/g, member.user.username)
        .replace(/\{server\}/g, member.guild.name)
        .replace(/\{memberCount\}/g, `${member.guild.memberCount}`);
}

async function buatPesanMember(member, settings, event) {
    const isWelcome = event === 'welcome';
    const template = settings[`${event}Message`] || (isWelcome
        ? 'Selamat datang {user} di **{server}**! Kamu adalah anggota ke-{memberCount}.'
        : '{username} telah meninggalkan **{server}**. Saat ini ada {memberCount} anggota.');
    const image = await buatGambarWelcome(member, event);
    const attachment = new AttachmentBuilder(image, { name: 'member-card.png' });
    const embed = new EmbedBuilder()
        .setColor(THEME_COLOR)
        .setDescription(formatTemplate(template, member))
        .setImage('attachment://member-card.png');

    return {
        embeds: [embed],
        files: [attachment],
        allowedMentions: isWelcome
            ? { parse: [], users: [member.id] }
            : { parse: [] }
    };
}

function embedPengumuman(guildName, authorName, isi) {
    return new EmbedBuilder()
        .setColor(THEME_COLOR)
        .setTitle(`📢 Pengumuman — ${guildName}`.slice(0, 256))
        .setDescription(isi.slice(0, 4000))
        .setAuthor({ name: authorName.slice(0, 256) })
        .setTimestamp();
}

function jadwalkanPengumuman(job) {
    const sisa = job.runAt - Date.now();
    if (sisa <= 0) {
        void kirimJadwalPengumuman(job);
        return;
    }
    const timer = setTimeout(() => {
        scheduleTimers.delete(job.id);
        if (job.runAt - Date.now() > 0) jadwalkanPengumuman(job);
        else void kirimJadwalPengumuman(job);
    }, Math.min(sisa, 2147480000));
    scheduleTimers.set(job.id, timer);
}

async function kirimJadwalPengumuman(job) {
    const channel = await client.channels.fetch(job.channelId).catch(error => {
        console.error('Gagal mencari channel jadwal pengumuman:', error);
        return null;
    });
    if (!channel || !channel.isTextBased()) {
        console.error(`Channel jadwal pengumuman ${job.channelId} tidak tersedia.`);
        adminSchedules.jobs = adminSchedules.jobs.filter(item => item.id !== job.id);
        simpanAdminSchedules();
        return;
    }
    try {
        await channel.send({
            embeds: [embedPengumuman(job.guildName, `Dijadwalkan oleh ${job.authorTag}`, job.content)],
            allowedMentions: { parse: [] }
        });
        adminSchedules.jobs = adminSchedules.jobs.filter(item => item.id !== job.id);
        simpanAdminSchedules();
    } catch (error) {
        console.error('Gagal mengirim pengumuman terjadwal:', error);
        job.attempts = (job.attempts || 0) + 1;
        if (job.attempts >= 3) {
            adminSchedules.jobs = adminSchedules.jobs.filter(item => item.id !== job.id);
            simpanAdminSchedules();
            console.error(`Jadwal pengumuman ${job.id} dibatalkan setelah 3 kegagalan.`);
            return;
        }
        job.runAt = Date.now() + 60000;
        simpanAdminSchedules();
        jadwalkanPengumuman(job);
    }
}

function pulihkanJadwalPengumuman() {
    if (!Array.isArray(adminSchedules.jobs)) adminSchedules.jobs = [];
    for (const job of adminSchedules.jobs) jadwalkanPengumuman(job);
}

function parseJumlah(input, saldo) {
    if (typeof input !== 'string') return null;
    if (input.toLowerCase() === 'all') return saldo > 0 ? saldo : null;
    if (!/^(?:\d+|\d{1,3}(?:\.\d{3})+)$/.test(input)) return null;
    const jumlah = Number(input.replace(/\./g, ''));
    return Number.isSafeInteger(jumlah) && jumlah > 0 ? jumlah : null;
}

const HEWAN = [
    { nama: 'Kelinci', kelangkaan: 'Common', nilai: 100, bobot: 40 },
    { nama: 'Rubah', kelangkaan: 'Common', nilai: 150, bobot: 30 },
    { nama: 'Rusa', kelangkaan: 'Uncommon', nilai: 300, bobot: 15 },
    { nama: 'Serigala', kelangkaan: 'Rare', nilai: 600, bobot: 8 },
    { nama: 'Panda', kelangkaan: 'Epic', nilai: 1200, bobot: 4 },
    { nama: 'Naga', kelangkaan: 'Legendary', nilai: 3000, bobot: 2 },
    { nama: 'Phoenix', kelangkaan: 'Mythical', nilai: 10000, bobot: 1 }
];

const ITEM_TOKO = {
    umpan: { nama: 'Umpan Hoki', harga: 500, deskripsi: 'Meningkatkan peluang menemukan hewan langka pada perburuan berikutnya.' }
};

function hewanAcak(pakaiUmpan = false) {
    const hewanDenganBobot = HEWAN.map(hewan => ({
        ...hewan,
        bobot: pakaiUmpan && !['Common'].includes(hewan.kelangkaan) ? hewan.bobot * 2 : hewan.bobot
    }));
    let undian = Math.random() * hewanDenganBobot.reduce((total, hewan) => total + hewan.bobot, 0);
    for (const hewan of hewanDenganBobot) {
        undian -= hewan.bobot;
        if (undian < 0) return hewan;
    }
    return HEWAN[0];
}

const transferDashboardPending = new Map();

function buatDashboardEmbed(guildId, member, pemberitahuan = null) {
    const server = ambilDataServer(guildId);
    const pemain = ambilDataPemain(server, member.id, guildId);
    const saldo = economyData.servers[guildId][member.id] || 0;
    const jumlahHewan = Object.values(pemain.zoo).reduce(
        (total, jumlah) => total + (Number.isSafeInteger(jumlah) && jumlah > 0 ? jumlah : 0),
        0
    );
    const xpMaks = xpUntukLevel(pemain.level);
    const progres = Math.min(12, Math.floor((pemain.xp / xpMaks) * 12));
    const persentaseXp = Math.min(100, Math.floor((pemain.xp / xpMaks) * 100));
    const dailySiap = Math.max(0, (pemain.lastDaily || 0) + COOLDOWN_HARIAN - Date.now());
    const dailyStatus = dailySiap === 0
        ? `🟢 Siap diklaim • hadiah **${formatUang(server.settings.dailyReward)} koin**`
        : `Tersedia <t:${Math.ceil((Date.now() + dailySiap) / 1000)}:R>`;
    return new EmbedBuilder()
        .setColor(THEME_COLOR)
        .setAuthor({ name: `LITTLE NOOK  •  ${member.displayName}` })
        .setThumbnail(member.user.displayAvatarURL({ size: 512 }))
        .setDescription(`${pemberitahuan ? `${pemberitahuan}\n\n` : ''}Selamat datang di pusat akunmu. Pilih aksi cepat atau jelajahi halaman melalui menu.`)
        .addFields(
            { name: '💰  DOMPET', value: `**${formatUang(saldo)}** koin`, inline: true },
            { name: '🎁  HADIAH HARIAN', value: dailyStatus, inline: true },
            { name: '🦒  KOLEKSI ZOO', value: `**${jumlahHewan}** hewan`, inline: true },
            { name: `⭐  LEVEL ${pemain.level}`, value: `${'🟦'.repeat(progres)}${'⬛'.repeat(12 - progres)}  **${persentaseXp}%**\n${formatUang(pemain.xp)} / ${formatUang(xpMaks)} EXP ke level berikutnya` },
            { name: '📈  AKTIVITAS', value: `🔥 Streak **${pemain.dailyStreak || 0} hari**　•　🏹 Hunt **${pemain.stats.hunts || 0}**　•　🎮 Game **${pemain.stats.games || 0}**` }
        )
        .setFooter({ text: 'PANEL PERSONAL  •  Kontrol hanya dapat digunakan olehmu' })
        .setTimestamp();
}

function buatKontrolDashboard(userId, halaman = 'dashboard') {
    const aksi = [
        ['daily', 'Klaim Daily', ButtonStyle.Success],
        ['hunt', 'Berburu', ButtonStyle.Primary],
        ['zoo', 'Lihat Zoo', ButtonStyle.Secondary]
    ];
    const barisAksi = new ActionRowBuilder().addComponents(
        ...aksi.map(([id, label, style]) =>
            new ButtonBuilder()
                .setCustomId(`dashboard:${userId}:${id}`)
                .setLabel(label)
                .setEmoji(id === 'daily' ? '🎁' : id === 'hunt' ? '🏹' : '🦒')
                .setStyle(style)
        )
    );
    const menuAksi = new ActionRowBuilder().addComponents(
        new StringSelectMenuBuilder()
            .setCustomId(`dashboard-action:${userId}`)
            .setPlaceholder('Aksi lainnya • transfer, jual hewan, toko...')
            .addOptions(
                { label: 'Transfer koin', value: 'transfer', description: 'Kirim koin ke anggota lain', emoji: '💸' },
                { label: 'Jual semua hewan', value: 'sell', description: 'Tukar seluruh koleksi menjadi koin', emoji: '🪙' },
                { label: 'Buka toko', value: 'shop', description: 'Lihat item yang tersedia', emoji: '🛒' },
                { label: 'Gunakan umpan', value: 'bait', description: 'Siapkan umpan untuk perburuan', emoji: '🪤' },
                { label: 'Segarkan ringkasan', value: 'refresh', description: 'Perbarui saldo dan progres akun', emoji: '🔄' }
            )
    );
    const menuHalaman = new ActionRowBuilder().addComponents(
        new StringSelectMenuBuilder()
            .setCustomId(`dashboard-page:${userId}`)
            .setPlaceholder('Buka halaman dashboard')
            .addOptions(
                { label: 'Ringkasan', value: 'dashboard', emoji: '🏠', default: halaman === 'dashboard' },
                { label: 'Koleksi Zoo', value: 'zoo', emoji: '🦒', default: halaman === 'zoo' },
                { label: 'Inventory', value: 'inventory', emoji: '🎒', default: halaman === 'inventory' },
                { label: 'Riwayat', value: 'history', emoji: '📜', default: halaman === 'history' },
                { label: 'Main Game', value: 'games', emoji: '🎮', default: halaman === 'games' }
            )
    );
    return [menuHalaman, barisAksi, menuAksi];
}

function buatModalJumlahTransfer(guildId, ownerId, targetId) {
    const nominal = new TextInputBuilder()
        .setCustomId('amount')
        .setLabel('Jumlah koin (contoh 1.000 atau all)')
        .setPlaceholder('1.000')
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
        .setMaxLength(20);
    return new ModalBuilder()
        .setCustomId(`dashboard-transfer-modal:${guildId}:${ownerId}:${targetId}`)
        .setTitle('Transfer Koin')
        .addComponents(new ActionRowBuilder().addComponents(nominal));
}

function klaimDaily(server, pemain, uangData, userId) {
    const sekarang = Date.now();
    const sisaCooldown = COOLDOWN_HARIAN - (sekarang - (pemain.lastDaily || 0));
    if (sisaCooldown > 0) return { ok: false, sisaCooldown };

    const jedaDaily = sekarang - (pemain.lastDaily || 0);
    pemain.dailyStreak = jedaDaily > 0 && jedaDaily <= COOLDOWN_HARIAN * 2
        ? Math.min((pemain.dailyStreak || 0) + 1, 7)
        : 1;
    const hadiah = server.settings.dailyReward + (pemain.dailyStreak - 1) * 100;
    uangData[userId] += hadiah;
    pemain.lastDaily = sekarang;
    simpanRiwayat(pemain, 'daily', hadiah, `streak ${pemain.dailyStreak}`);
    simpanUang();
    simpanOwoState();
    return { ok: true, hadiah, streak: pemain.dailyStreak, saldo: uangData[userId] };
}

function berburu(server, pemain, guildId, userId) {
    const cooldown = 60 * 1000;
    const sisaCooldown = cooldown - (Date.now() - (pemain.lastHunt || 0));
    if (sisaCooldown > 0) return { ok: false, sisaCooldown };
    const pakaiUmpan = Boolean(pemain.huntBoost);
    const hewan = hewanAcak(pakaiUmpan);
    pemain.huntBoost = false;
    pemain.lastHunt = Date.now();
    pemain.zoo[hewan.nama] = (pemain.zoo[hewan.nama] || 0) + 1;
    pemain.stats.hunts = (pemain.stats.hunts || 0) + 1;
    simpanRiwayat(pemain, 'hunt', null, `${hewan.kelangkaan}: ${hewan.nama}`);
    simpanOwoState();
    return { ok: true, hewan, pakaiUmpan, cooldown };
}

function ringkasanZoo(pemain) {
    let totalKoin = 0;
    let totalHewan = 0;
    const hewanValid = [];
    for (const [nama, jumlah] of Object.entries(pemain.zoo)) {
        const hewan = HEWAN.find(item => item.nama === nama);
        if (!hewan || !Number.isSafeInteger(jumlah) || jumlah <= 0) continue;
        const nilai = hewan.nilai * jumlah;
        if (!Number.isSafeInteger(nilai) || !Number.isSafeInteger(totalKoin + nilai) ||
            !Number.isSafeInteger(totalHewan + jumlah)) {
            return { ok: false, reason: 'overflow' };
        }
        totalKoin += nilai;
        totalHewan += jumlah;
        hewanValid.push(nama);
    }
    if (!totalHewan) return { ok: false, reason: 'empty' };
    return { ok: true, totalKoin, totalHewan, hewanValid };
}

function jualZoo(pemain, uangData, userId) {
    const ringkasan = ringkasanZoo(pemain);
    if (!ringkasan.ok) return ringkasan;
    if (!Number.isSafeInteger(uangData[userId] + ringkasan.totalKoin)) {
        return { ok: false, reason: 'saldo_limit' };
    }
    for (const nama of ringkasan.hewanValid) delete pemain.zoo[nama];
    uangData[userId] += ringkasan.totalKoin;
    simpanRiwayat(pemain, 'jual hewan', ringkasan.totalKoin, `${ringkasan.totalHewan} hewan`);
    simpanUang();
    simpanOwoState();
    return { ok: true, hasilJual: ringkasan.totalKoin, hewanTerjual: ringkasan.totalHewan };
}

function mulaiCooldownGame(pemain, game, cooldownMs) {
    if (!pemain.gameCooldowns || typeof pemain.gameCooldowns !== 'object' || Array.isArray(pemain.gameCooldowns)) {
        pemain.gameCooldowns = {};
    }
    const now = Date.now();
    const sisa = cooldownMs - (now - (pemain.gameCooldowns[game] || 0));
    if (sisa > 0) return sisa;
    pemain.gameCooldowns[game] = now;
    simpanOwoState();
    return 0;
}

function tombolMainLagi(userId, game, taruhan, pilihan = 'none') {
    return [new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId(`replay:${game}:${userId}:${taruhan}:${pilihan}`)
            .setLabel(game === 'hunt' ? 'Berburu Lagi' : game === 'slot' ? 'Putar Lagi' : game === 'cf' ? 'Lempar Lagi' : 'Main Lagi')
            .setEmoji(game === 'hunt' ? '🏹' : game === 'slot' ? '🎰' : game === 'cf' ? '🪙' : '🎲')
            .setStyle(ButtonStyle.Primary)
    )];
}

function buatZooEmbed(member, pemain) {
    const koleksi = Object.entries(pemain.zoo).filter(([, jumlah]) => Number.isSafeInteger(jumlah) && jumlah > 0);
    const totalHewan = koleksi.reduce((sum, [, jumlah]) => sum + jumlah, 0);
    const nilaiZoo = koleksi.reduce((sum, [nama, jumlah]) => {
        const hewan = HEWAN.find(item => item.nama === nama);
        return sum + (hewan ? hewan.nilai * jumlah : 0);
    }, 0);
    const deskripsi = koleksi.length
        ? koleksi.map(([nama, jumlah]) => {
            const hewan = HEWAN.find(item => item.nama === nama);
            return `• **${nama}** ×${formatUang(jumlah)}${hewan ? ` — ${hewan.kelangkaan} • ${formatUang(hewan.nilai)} koin/ekor` : ''}`;
        }).join('\n')
        : 'Zoo kamu masih kosong.\n\nGunakan **Berburu** untuk mulai mengumpulkan hewan.';
    return new EmbedBuilder()
        .setColor(THEME_COLOR)
        .setAuthor({ name: `KOLEKSI PEMAIN  •  ${member.displayName}` })
        .setTitle('🦒 Zoo')
        .addFields(
            { name: 'Jumlah hewan', value: `**${formatUang(totalHewan)}**`, inline: true },
            { name: 'Estimasi nilai jual', value: `**${formatUang(nilaiZoo)} koin**`, inline: true }
        )
        .setDescription(deskripsi)
        .setThumbnail(member.user.displayAvatarURL({ size: 256 }))
        .setFooter({ text: 'Hewan dapat dijual seluruhnya melalui Aksi lainnya → Jual semua hewan' })
        .setTimestamp();
}

function pengaliMines(jumlahBom, jumlahBerlian) {
    if (jumlahBerlian === 0) return 1;
    let peluangBertahan = 1;
    for (let pilihan = 0; pilihan < jumlahBerlian; pilihan++) {
        peluangBertahan *= (9 - jumlahBom - pilihan) / (9 - pilihan);
    }
    return 0.95 / peluangBertahan;
}

function buatMenuGame(userId) {
    return new ActionRowBuilder().addComponents(
        new StringSelectMenuBuilder()
            .setCustomId(`dashboard-game:${userId}`)
            .setPlaceholder('Pilih permainan')
            .addOptions(
                { label: 'Coinflip', value: 'cf', description: 'Pilih sisi koin dan tentukan taruhan', emoji: '🪙' },
                { label: 'Animal Slot', value: 'slot', description: 'Putar slot dengan taruhan koin', emoji: '🎰' },
                { label: 'Adu Angka', value: 'gamble', description: 'Adu angka dadu 0–100', emoji: '🎲' },
                { label: 'Mines', value: 'mines', description: 'Cari berlian dan amankan cash out', emoji: '💎' }
            )
    );
}

function buatModalTaruhan(userId, guildId, game) {
    const judul = { cf: 'Coinflip', slot: 'Animal Slot', gamble: 'Adu Angka', mines: 'Mines' }[game];
    if (!judul) return null;
    const modal = new ModalBuilder()
        .setCustomId(`dashboard-game-modal:${guildId}:${userId}:${game}`)
        .setTitle(`Mulai ${judul}`);
    const taruhan = new TextInputBuilder()
        .setCustomId('bet')
        .setLabel('Taruhan (angka, titik ribuan, atau all)')
        .setPlaceholder('1.000')
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
        .setMaxLength(20);
    modal.addComponents(new ActionRowBuilder().addComponents(taruhan));
    if (game === 'cf') {
        modal.addComponents(new ActionRowBuilder().addComponents(
            new TextInputBuilder().setCustomId('side').setLabel('Pilih head atau tail').setPlaceholder('head').setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(4)
        ));
    }
    if (game === 'mines') {
        modal.addComponents(new ActionRowBuilder().addComponents(
            new TextInputBuilder().setCustomId('bombs').setLabel('Jumlah bom (1 sampai 8)').setPlaceholder('3').setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(1)
        ));
    }
    return modal;
}

async function jalankanGameUI(interaction, { game, userId, taruhan, pilihan = 'none', jumlahBom = 3 }) {
    const guild = interaction.guild;
    if (!guild || interaction.user.id !== userId) {
        await interaction.reply({ content: 'Permainan ini hanya dapat dijalankan oleh pemilik dashboard.', ephemeral: true });
        return;
    }
    const server = ambilDataServer(guild.id);
    const pemain = ambilDataPemain(server, userId, guild.id);
    const uangData = economyData.servers[guild.id];
    if (!Number.isSafeInteger(taruhan) || taruhan < 1 || uangData[userId] < taruhan) {
        await interaction.reply({ content: 'Taruhan tidak valid atau saldo koin kamu tidak cukup.', ephemeral: true });
        return;
    }
    if (game === 'cf' && !['head', 'tail'].includes(pilihan)) {
        await interaction.reply({ content: 'Pilih sisi `head` atau `tail` untuk coinflip.', ephemeral: true });
        return;
    }
    if (game === 'mines' && (!Number.isInteger(jumlahBom) || jumlahBom < 1 || jumlahBom > 8)) {
        await interaction.reply({ content: 'Jumlah bom harus 1 sampai 8.', ephemeral: true });
        return;
    }
    if (!['cf', 'slot', 'gamble', 'mines'].includes(game)) {
        await interaction.reply({ content: 'Jenis permainan tidak dikenal.', ephemeral: true });
        return;
    }
    if ((game === 'slot' && (!Number.isSafeInteger(taruhan * 5) || !Number.isSafeInteger(uangData[userId] - taruhan + taruhan * 5))) ||
        (game === 'mines' && !Number.isSafeInteger(taruhan * 10)) ||
        (game !== 'slot' && game !== 'mines' && !Number.isSafeInteger(uangData[userId] + taruhan))) {
        await interaction.reply({ content: 'Taruhan terlalu besar untuk diproses dengan aman.', ephemeral: true });
        return;
    }
    const sisaCooldown = mulaiCooldownGame(pemain, game, 10000);
    if (sisaCooldown > 0) {
        await interaction.reply({ content: `⏳ Kamu bisa bermain lagi <t:${Math.ceil((Date.now() + sisaCooldown) / 1000)}:R>.`, ephemeral: true });
        return;
    }

    uangData[userId] -= taruhan;
    if (game === 'mines') {
        pemain.stats.games = (pemain.stats.games || 0) + 1;
        simpanRiwayat(pemain, 'mines mulai', -taruhan, `${jumlahBom} bom`);
    }
    simpanUang();
    simpanOwoState();
    let settled = false;
    try {
        if (interaction.isButton()) await interaction.deferUpdate();
        else await interaction.deferReply({ ephemeral: true });

        if (game === 'mines') {
            const aman = new Set();
            const pilihanKotak = new Map();
            const bom = new Set();
            while (bom.size < jumlahBom) bom.add(Math.floor(Math.random() * 9));
            let selesai = false;
            let processing = false;
            const hitungCashOut = () => Math.floor(taruhan * pengaliMines(jumlahBom, aman.size));
            const buatGrid = () => {
                const rows = [];
                for (let awal = 0; awal < 9; awal += 3) {
                    rows.push(new ActionRowBuilder().addComponents(
                        ...Array.from({ length: 3 }, (_, offset) => {
                            const nomor = awal + offset;
                            const status = pilihanKotak.get(nomor);
                            const isBomb = selesai && bom.has(nomor);
                            return new ButtonBuilder()
                                .setCustomId(`mines-cell-${nomor}`)
                                .setLabel(status === 'rolling' ? '🔄' : isBomb ? '💣' : aman.has(nomor) ? '💎' : `${nomor + 1}`)
                                .setStyle(isBomb ? ButtonStyle.Danger : aman.has(nomor) ? ButtonStyle.Success : ButtonStyle.Primary)
                                .setDisabled(selesai || processing || status === 'rolling' || status === 'mine' || aman.has(nomor));
                        })
                    ));
                }
                rows.push(new ActionRowBuilder().addComponents(
                    new ButtonBuilder().setCustomId('mines-cashout').setLabel('Cash Out').setStyle(ButtonStyle.Secondary).setDisabled(selesai || processing)
                ));
                return rows;
            };
            const gameMessage = await interaction.editReply({
                content: `💎 **MINES 3×3** — Taruhan **${formatUang(taruhan)} koin**\n💣 Bom: **${jumlahBom}** | 💎 Berlian aman: **0/${9 - jumlahBom}**\nCash out saat ini: **${formatUang(hitungCashOut())} koin**\nPilih kotak atau cash out kapan saja.`,
                components: buatGrid()
            });
            const collector = gameMessage.createMessageComponentCollector({
                time: 120000,
                filter: component => component.customId.startsWith('mines-')
            });
            collector.on('collect', async component => {
                try {
                    if (component.user.id !== userId) {
                        await component.reply({ content: 'Permainan ini bukan milikmu.', ephemeral: true });
                        return;
                    }
                    if (selesai || processing) {
                        await component.reply({ content: selesai ? 'Permainan ini sudah selesai.' : 'Tunggu sampai pilihan sebelumnya selesai.', ephemeral: true });
                        return;
                    }
                    if (component.customId === 'mines-cashout') {
                        const hadiah = hitungCashOut();
                        uangData[userId] += hadiah;
                        simpanRiwayat(pemain, 'mines cash out', hadiah - taruhan, `${aman.size} berlian, ${jumlahBom} bom`);
                        simpanUang();
                        simpanOwoState();
                        settled = true;
                        selesai = true;
                        collector.stop('selesai');
                        await component.update({
                            content: `💰 Cash out **${formatUang(hadiah)} koin** berhasil. Kamu mengamankan ${aman.size} berlian. Saldo: **${formatUang(uangData[userId])} koin**.`,
                            components: tombolMainLagi(userId, 'mines', taruhan, String(jumlahBom))
                        });
                        return;
                    }
                    const nomor = Number(component.customId.slice('mines-cell-'.length));
                    if (!Number.isInteger(nomor) || nomor < 0 || nomor > 8 || aman.has(nomor)) {
                        await component.reply({ content: 'Kotak tidak valid atau sudah dipilih.', ephemeral: true });
                        return;
                    }
                    processing = true;
                    collector.resetTimer();
                    pilihanKotak.set(nomor, 'rolling');
                    await component.update({
                        content: `💎 **MINES 3×3** — Bom **${jumlahBom}** | Berlian **${aman.size}/${9 - jumlahBom}**\nMemeriksa kotak ${nomor + 1}...`,
                        components: buatGrid()
                    });
                    await jeda(700);
                    if (bom.has(nomor)) {
                        pilihanKotak.set(nomor, 'mine');
                        selesai = true;
                        simpanRiwayat(pemain, 'mines kalah', -taruhan, `${aman.size} berlian, ${jumlahBom} bom`);
                        simpanUang();
                        simpanOwoState();
                        settled = true;
                        collector.stop('selesai');
                        await component.editReply({
                            content: `💥 Terkena bom! Kamu menemukan ${aman.size} berlian sebelum kalah. Taruhan **${formatUang(taruhan)} koin** hilang.`,
                            components: [...buatGrid(), ...tombolMainLagi(userId, 'mines', taruhan, String(jumlahBom))]
                        });
                        return;
                    }
                    aman.add(nomor);
                    pilihanKotak.set(nomor, 'diamond');
                    if (aman.size === 9 - jumlahBom) {
                        const hadiah = hitungCashOut();
                        uangData[userId] += hadiah;
                        simpanRiwayat(pemain, 'mines jackpot', hadiah - taruhan, `${aman.size} berlian, ${jumlahBom} bom`);
                        simpanUang();
                        simpanOwoState();
                        settled = true;
                        selesai = true;
                        collector.stop('selesai');
                        await component.editReply({
                            content: `🏆 Semua berlian ditemukan! Kamu menerima **${formatUang(hadiah)} koin**. Saldo: **${formatUang(uangData[userId])} koin**.`,
                            components: [...buatGrid(), ...tombolMainLagi(userId, 'mines', taruhan, String(jumlahBom))]
                        });
                        return;
                    }
                    processing = false;
                    await component.editReply({
                        content: `💎 Berlian ditemukan! Kotak ${nomor + 1} aman.\nBom: **${jumlahBom}** | Berlian: **${aman.size}/${9 - jumlahBom}**\nCash out: **${formatUang(hitungCashOut())} koin**.`,
                        components: buatGrid()
                    });
                } catch (error) {
                    console.error('Gagal memproses interaksi Mines dashboard:', error);
                    processing = false;
                    if (!component.replied && !component.deferred) {
                        await component.reply({ content: 'Aksi Mines gagal diproses. Coba kembali.', ephemeral: true }).catch(replyError => console.error('Gagal membalas interaksi Mines:', replyError));
                    }
                }
            });
            collector.on('end', async (_, reason) => {
                if (reason !== 'time' || selesai) return;
                const hadiah = hitungCashOut();
                uangData[userId] += hadiah;
                simpanRiwayat(pemain, 'mines cash out otomatis', hadiah - taruhan, `${aman.size} berlian, ${jumlahBom} bom`);
                simpanUang();
                simpanOwoState();
                settled = true;
                selesai = true;
                try {
                    await gameMessage.edit({
                        content: `⏳ Waktu habis. Cash out otomatis **${formatUang(hadiah)} koin** untuk ${aman.size} berlian. Saldo: **${formatUang(uangData[userId])} koin**.`,
                        components: tombolMainLagi(userId, 'mines', taruhan, String(jumlahBom))
                    });
                } catch (error) {
                    console.error('Gagal menyelesaikan Mines setelah timeout:', error);
                }
            });
            return;
        }

        let perubahanSaldo = 0;
        let hasilDetail = '';
        let narasi = '';
        if (game === 'cf') {
            await interaction.editReply({ content: `🪙 **COINFLIP** — taruhan **${formatUang(taruhan)} koin**\nKoin dilempar...` });
            for (const bingkai of ['⚪', '🟡', '⚪']) {
                await jeda(400);
                await interaction.editReply({ content: `🪙 **COINFLIP**\n${bingkai} Koin berputar...` });
            }
            hasilDetail = Math.random() < 0.5 ? 'head' : 'tail';
            const menang = hasilDetail === pilihan;
            perubahanSaldo = menang ? taruhan : -taruhan;
            if (menang) uangData[userId] += taruhan;
            narasi = menang ? `🎉 Kamu menang **${formatUang(taruhan)} koin**!` : `💀 Kamu kalah **${formatUang(taruhan)} koin**.`;
        } else if (game === 'slot') {
            const simbol = ['🐺', '🐰', '🦊', '🐼', '🐉'];
            const acak = () => Array.from({ length: 3 }, () => simbol[Math.floor(Math.random() * simbol.length)]);
            const hasil = acak();
            for (let putaran = 0; putaran < 6; putaran++) {
                await jeda(400);
                const gulungan = acak();
                if (putaran >= 3) gulungan[0] = hasil[0];
                if (putaran >= 4) gulungan[1] = hasil[1];
                if (putaran >= 5) gulungan[2] = hasil[2];
                await interaction.editReply({ content: `🎰 **ANIMAL SLOT** — taruhan **${formatUang(taruhan)} koin**\n[ ${gulungan.join(' | ')} ]` });
            }
            const sama = hasil.filter(item => item === hasil[0]).length;
            const hadiah = sama === 3 ? taruhan * 5 : sama === 2 || new Set(hasil).size === 2 ? Math.floor(taruhan * 1.5) : 0;
            perubahanSaldo = hadiah - taruhan;
            uangData[userId] += hadiah;
            hasilDetail = hasil.join(' ');
            narasi = hadiah > taruhan ? `🎉 Jackpot! Hadiah **${formatUang(hadiah)} koin**.` : hadiah > 0 ? `✨ Menang **${formatUang(hadiah)} koin**.` : `💀 Zonk! Taruhan **${formatUang(taruhan)} koin** hilang.`;
        } else {
            let angkaPemain = 0;
            let angkaBot = 0;
            for (let putaran = 0; putaran < 5; putaran++) {
                angkaPemain = Math.floor(Math.random() * 101);
                angkaBot = Math.floor(Math.random() * 101);
                await jeda(350);
                await interaction.editReply({ content: `🎲 **ADU ANGKA** — taruhan **${formatUang(taruhan)} koin**\nKamu: **${angkaPemain}** | Lawan: **${angkaBot}**` });
            }
            const menang = angkaPemain > angkaBot;
            const seri = angkaPemain === angkaBot;
            perubahanSaldo = seri ? 0 : menang ? taruhan : -taruhan;
            if (menang || seri) uangData[userId] += taruhan;
            hasilDetail = `${angkaPemain} vs ${angkaBot}`;
            narasi = seri ? '🤝 Seri! Taruhan dikembalikan.' : menang ? `🎉 Kamu menang **${formatUang(taruhan)} koin**!` : `💀 Kamu kalah **${formatUang(taruhan)} koin**.`;
        }
        pemain.stats.games = (pemain.stats.games || 0) + 1;
        simpanRiwayat(pemain, game === 'cf' ? 'coinflip' : game, perubahanSaldo, hasilDetail);
        simpanUang();
        simpanOwoState();
        settled = true;
        const hasil = game === 'cf'
            ? `🪙 Hasil: **${hasilDetail.toUpperCase()}**\n${narasi}`
            : game === 'slot'
                ? `🎰 [ ${hasilDetail} ]\n${narasi}`
                : `🎲 **${hasilDetail}**\n${narasi}`;
        await interaction.editReply({
            content: `${hasil}\nSaldo: **${formatUang(uangData[userId])} koin**.`,
            components: tombolMainLagi(userId, game, taruhan, pilihan)
        });
    } catch (error) {
        if (!settled) {
            uangData[userId] += taruhan;
            pemain.gameCooldowns[game] = 0;
            simpanUang();
            simpanOwoState();
        }
        console.error(`Gagal menjalankan game UI ${game}:`, error);
        if (interaction.deferred || interaction.replied) {
            await interaction.editReply({
                content: settled ? 'Hasil sudah disimpan, tetapi pesan gagal diperbarui.' : 'Permainan gagal diproses; taruhan telah dikembalikan.',
                components: []
            }).catch(replyError => console.error('Gagal memberi status game UI:', replyError));
        } else {
            await interaction.reply({ content: 'Permainan gagal diproses.', ephemeral: true }).catch(replyError => console.error('Gagal membalas game UI:', replyError));
        }
    }
}

if (!fs.existsSync(PATH_FILTER)) fs.writeFileSync(PATH_FILTER, JSON.stringify({ globalWords: [] }));
let filterData = JSON.parse(fs.readFileSync(PATH_FILTER, 'utf8'));
if (Array.isArray(filterData)) {
    if (filterData.some(kata => typeof kata !== 'string')) throw new Error('Isi bad_words.json harus berupa array teks.');
    filterData = { globalWords: filterData };
    fs.writeFileSync(PATH_FILTER, JSON.stringify(filterData, null, 2));
}
if (!filterData || typeof filterData !== 'object' || Array.isArray(filterData)) {
    throw new Error('Isi bad_words.json harus berupa array kata lama atau objek globalWords.');
}
if (!Array.isArray(filterData.globalWords) || filterData.globalWords.some(kata => typeof kata !== 'string')) {
    throw new Error('Properti globalWords di bad_words.json harus berupa array teks.');
}

function normalisasiTeks(teks) {
    return teks
        .normalize('NFKC')
        .toLocaleLowerCase('id-ID')
        .replace(/[^\p{L}\p{N}]+/gu, ' ')
        .trim();
}

function pesanMengandungPemicu(pesan, pemicu) {
    const pesanNormal = normalisasiTeks(pesan);
    const pemicuNormal = normalisasiTeks(pemicu);
    return Boolean(pemicuNormal) && ` ${pesanNormal} `.includes(` ${pemicuNormal} `);
}

function ambilPengaturanAutoRespons(server) {
    if (!Array.isArray(server.settings.autoResponses)) server.settings.autoResponses = [];
    server.settings.autoResponsesEnabled = server.settings.autoResponsesEnabled !== false;
    return server.settings.autoResponses;
}

function amanUntukTeksDiscord(teks) {
    return teks.replace(/`/g, 'ˋ').replace(/@/g, '@\u200b');
}

function simpanKataFilter() {
    simpanOwoState();
}

function xpUntukLevel(level) {
    return 100 + level * 50;
}

async function berikanXP(message, pemain) {
    if (message.content.trim().length < 4) return;
    const sekarang = Date.now();
    if (sekarang - (pemain.lastXpAt || 0) < 60000) return;
    pemain.lastXpAt = sekarang;
    pemain.stats.messages = (pemain.stats.messages || 0) + 1;
    pemain.xp = (pemain.xp || 0) + 10 + Math.floor(Math.random() * 11);

    let naikLevel = false;
    while (pemain.xp >= xpUntukLevel(pemain.level)) {
        pemain.xp -= xpUntukLevel(pemain.level);
        pemain.level++;
        naikLevel = true;
    }
    simpanOwoState();

    if (!naikLevel) return;
    const embed = new EmbedBuilder()
        .setColor(THEME_COLOR)
        .setTitle('🎉 Level naik!')
        .setDescription(`${message.author} mencapai **Level ${pemain.level}**!`)
        .setThumbnail(message.author.displayAvatarURL({ size: 256 }))
        .setFooter({ text: `XP menuju level berikutnya: ${pemain.xp}/${xpUntukLevel(pemain.level)}` })
        .setTimestamp();
    try {
        await message.channel.send({ embeds: [embed] });
    } catch (error) {
        console.error('Gagal mengirim pengumuman level:', error);
    }
}

client.on('clientReady', () => {
    console.log(`✅ Bot ${client.user.tag} berhasil online!`);
    client.user.setActivity('Anggota Server', { type: ActivityType.Watching });
    pulihkanJadwalPengumuman();
});

client.on('messageCreate', async message => {
    if (message.author.bot) return;

    const isCommand = message.content.startsWith(PREFIX);
    const args = isCommand ? message.content.slice(PREFIX.length).trim().split(/ +/) : [];
    const command = isCommand ? args.shift().toLowerCase() : '';
    const guildId = message.guild?.id;
    const serverData = guildId ? ambilDataServer(guildId) : null;

    if (command === 'modlog') {
        if (!serverData || !message.member.permissions.has(PermissionsBitField.Flags.ManageGuild)) {
            return message.reply('❌ Perintah ini hanya untuk admin server dengan izin **Manage Server**.');
        }
        if (args[0]?.toLowerCase() === 'off') {
            delete modLogConfig[guildId];
            fs.writeFileSync(PATH_MOD_LOG, JSON.stringify(modLogConfig, null, 2));
            return message.reply('✅ Log moderasi dinonaktifkan.');
        }
        const channel = message.mentions.channels.first();
        if (!channel || !channel.isTextBased()) return message.reply('⚠️ Gunakan `ltn modlog set #channel` atau `ltn modlog off`.');
        modLogConfig[guildId] = channel.id;
        fs.writeFileSync(PATH_MOD_LOG, JSON.stringify(modLogConfig, null, 2));
        return message.reply(`✅ Log moderasi akan dikirim ke ${channel}.`);
    }

    if (command === 'announce' || command === 'pengumuman') {
        if (!serverData || !message.member.permissions.has(PermissionsBitField.Flags.ManageGuild)) {
            return message.reply('❌ Perintah ini hanya untuk admin server dengan izin **Manage Server**.');
        }

        const channel = message.mentions.channels.first();
        if (!channel || !channel.isTextBased() || !channel.send) {
            return message.reply('⚠️ Tentukan channel teks. Contoh: `ltn announce #pengumuman Pesan` atau `ltn announce jadwal #pengumuman 2h Pesan`.');
        }

        const jadwal = args[0]?.toLowerCase() === 'jadwal';
        const rawText = message.content.slice(PREFIX.length + command.length).trim();
        const channelMatch = rawText.match(/^jadwal\s+<#[0-9]{17,20}>\s+/i);
        const jedaJadwal = jadwal ? parseDurasi(args[2]) : null;
        if (jadwal && (!channelMatch || !jedaJadwal || jedaJadwal > 7 * 86400000)) {
            return message.reply('⚠️ Format jadwal: `ltn announce jadwal #channel <durasi> <pesan>`; durasi contoh `30m`, `2h`, maksimal 7 hari.');
        }
        const isiPengumuman = jadwal
            ? rawText.replace(/^jadwal\s+<#[0-9]{17,20}>\s+\S+\s*/i, '').trim()
            : rawText.replace(/^<#[0-9]{17,20}>\s*/, '').trim();
        if (!isiPengumuman) return message.reply('⚠️ Tulis isi pengumuman setelah mention channel.');
        if (isiPengumuman.length > 4000) return message.reply('⚠️ Isi pengumuman maksimal 4.000 karakter.');

        if (jadwal) {
            if (!Array.isArray(adminSchedules.jobs)) adminSchedules.jobs = [];
            const job = {
                id: `${Date.now()}-${message.id}`,
                guildId,
                guildName: message.guild.name,
                channelId: channel.id,
                authorTag: message.author.tag,
                content: isiPengumuman,
                runAt: Date.now() + jedaJadwal
            };
            adminSchedules.jobs.push(job);
            simpanAdminSchedules();
            jadwalkanPengumuman(job);
            return message.reply(`✅ Pengumuman dijadwalkan untuk <t:${Math.floor(job.runAt / 1000)}:F> di ${channel}.`);
        }

        try {
            await channel.send({
                embeds: [embedPengumuman(message.guild.name, `Diumumkan oleh ${message.author.tag}`, isiPengumuman)],
                allowedMentions: { parse: [] }
            });
            return message.reply(`✅ Pengumuman berhasil dikirim ke ${channel}. Ping massal dinonaktifkan.`);
        } catch (error) {
            console.error('Gagal mengirim pengumuman admin:', error);
            return message.reply('❌ Pengumuman gagal dikirim. Pastikan bot memiliki izin **View Channel** dan **Send Messages** di channel tujuan.');
        }
    }

    if (['welcome', 'goodbye', 'autorole'].includes(command)) {
        if (!serverData || !message.member.permissions.has(PermissionsBitField.Flags.ManageGuild)) {
            return message.reply('❌ Perintah ini hanya untuk admin server dengan izin **Manage Server**.');
        }
        const aksi = args.shift()?.toLowerCase();
        const targetSetting = command === 'welcome' ? 'welcome' : command === 'goodbye' ? 'goodbye' : 'autorole';
        const mentionChannel = message.mentions.channels.first();
        const mentionRole = message.mentions.roles.first();
        if (aksi === 'off') {
            delete serverData.settings[`${targetSetting}ChannelId`];
            if (targetSetting === 'autorole') delete serverData.settings.autoroleId;
            simpanOwoState();
            return message.reply(`✅ Fitur ${command} dinonaktifkan.`);
        }
        if (aksi === 'pesan' && targetSetting !== 'autorole') {
            const text = message.content.slice(PREFIX.length).trim().replace(/^\S+\s+\S+\s+/, '').trim();
            if (!text) return message.reply(`⚠️ Masukkan pesan setelah \`ltn ${command} pesan\`.`);
            serverData.settings[`${targetSetting}Message`] = text.slice(0, 1000);
            simpanOwoState();
            return message.reply(`✅ Pesan ${command} berhasil diperbarui. Placeholder: \`{user}\`, \`{username}\`, \`{server}\`, \`{memberCount}\`.`);
        }
        if (aksi !== 'set') {
            const usage = targetSetting === 'autorole'
                ? `\`ltn autorole set @role\` atau \`ltn autorole off\``
                : `\`ltn ${command} set #channel [pesan]\`, \`ltn ${command} pesan <pesan>\`, atau \`ltn ${command} off\``;
            return message.reply(`⚠️ Gunakan ${usage}.`);
        }
        if (targetSetting === 'autorole') {
            if (!mentionRole) return message.reply('⚠️ Sebutkan role yang akan diberikan, contoh `ltn autorole set @Anggota`.');
            serverData.settings.autoroleId = mentionRole.id;
            simpanOwoState();
            return message.reply(`✅ Role otomatis anggota baru diatur ke ${mentionRole}. Bot memerlukan izin **Manage Roles** dan role bot harus di atas role tersebut.`);
        }
        if (!mentionChannel || !mentionChannel.isTextBased()) return message.reply('⚠️ Sebutkan channel teks tujuan.');
        const key = `${targetSetting}ChannelId`;
        serverData.settings[key] = mentionChannel.id;
        const text = message.content.replace(/^.*?<#[0-9]{17,20}>\s*/i, '').trim();
        if (text) serverData.settings[`${targetSetting}Message`] = text.slice(0, 1000);
        simpanOwoState();
        return message.reply(`✅ ${command === 'welcome' ? 'Welcome' : 'Goodbye'} diatur ke ${mentionChannel}.${text ? ' Template tersimpan.' : ''} Placeholder: \`{user}\`, \`{username}\`, \`{server}\`, \`{memberCount}\`.`);
    }

    if (command === 'verify') {
        if (!serverData || !message.member.permissions.has(PermissionsBitField.Flags.ManageGuild)) {
            return message.reply('❌ Perintah ini hanya untuk admin server dengan izin **Manage Server**.');
        }
        const channel = message.mentions.channels.first();
        const role = message.mentions.roles.first();
        if (args[0]?.toLowerCase() !== 'setup' || !channel?.isTextBased() || !role) {
            return message.reply('⚠️ Gunakan `ltn verify setup #channel @role` untuk membuat tombol verifikasi.');
        }
        serverData.settings.verifyRoleId = role.id;
        simpanOwoState();
        try {
            await channel.send({
                embeds: [new EmbedBuilder().setColor(SUCCESS_COLOR).setTitle('✅ Verifikasi Anggota').setDescription('Tekan tombol di bawah untuk mendapatkan akses ke server.')],
                components: [new ActionRowBuilder().addComponents(
                    new ButtonBuilder().setCustomId(`verify:${guildId}`).setLabel('Verifikasi').setStyle(ButtonStyle.Success)
                )]
            });
            return message.reply(`✅ Panel verifikasi dikirim ke ${channel}.`);
        } catch (error) {
            console.error('Gagal mengirim panel verifikasi:', error);
            return message.reply('❌ Panel verifikasi gagal dikirim. Pastikan bot dapat melihat dan mengirim pesan di channel tersebut.');
        }
    }

    if (command === 'reportpanel' || command === 'adminpanel') {
        if (!serverData || !message.member.permissions.has(PermissionsBitField.Flags.ManageGuild)) {
            return message.reply('❌ Perintah ini hanya untuk admin server dengan izin **Manage Server**.');
        }
        const channel = message.mentions.channels.first() || message.channel;
        if (!channel.isTextBased()) return message.reply('⚠️ Pilih channel teks.');
        try {
            const isReport = command === 'reportpanel';
            if (isReport) {
                serverData.settings.reportChannelId = channel.id;
                simpanOwoState();
            }
            await channel.send(isReport ? {
                embeds: [new EmbedBuilder().setColor(THEME_COLOR).setTitle('🚩 Laporkan Anggota').setDescription('Gunakan tombol untuk mengirim laporan rahasia kepada tim moderasi.')],
                components: [new ActionRowBuilder().addComponents(
                    new ButtonBuilder().setCustomId(`report:${guildId}`).setLabel('Buat Laporan').setStyle(ButtonStyle.Danger)
                )]
            } : {
                embeds: [new EmbedBuilder().setColor(THEME_COLOR).setTitle('⚙️ Panel Konfigurasi Admin').setDescription('Pilih pengaturan untuk dikonfigurasi. Hanya admin dengan izin Manage Server yang dapat mengubahnya.')],
                components: [
                    new ActionRowBuilder().addComponents(
                        new ButtonBuilder().setCustomId(`admincfg:welcome:${guildId}`).setLabel('Welcome').setStyle(ButtonStyle.Primary),
                        new ButtonBuilder().setCustomId(`admincfg:goodbye:${guildId}`).setLabel('Goodbye').setStyle(ButtonStyle.Primary),
                        new ButtonBuilder().setCustomId(`admincfg:autorole:${guildId}`).setLabel('Auto-role').setStyle(ButtonStyle.Primary),
                        new ButtonBuilder().setCustomId(`admincfg:report:${guildId}`).setLabel('Channel Laporan').setStyle(ButtonStyle.Secondary),
                        new ButtonBuilder().setCustomId(`admincfg:verify:${guildId}`).setLabel('Role Verifikasi').setStyle(ButtonStyle.Secondary)
                    ),
                    new ActionRowBuilder().addComponents(
                        new ButtonBuilder().setCustomId(`admincfg:modlog:${guildId}`).setLabel('Log Moderasi').setStyle(ButtonStyle.Secondary)
                    )
                ]
            });
            return message.reply(`✅ ${command === 'reportpanel' ? 'Panel laporan' : 'Panel konfigurasi admin'} dikirim ke ${channel}.`);
        } catch (error) {
            console.error(`Gagal mengirim ${command}:`, error);
            return message.reply('❌ Panel gagal dikirim. Periksa izin bot di channel tujuan.');
        }
    }

    if (['slowmode', 'lock', 'unlock'].includes(command)) {
        if (!serverData || !message.member.permissions.has(PermissionsBitField.Flags.ManageChannels)) {
            return message.reply('❌ Perintah ini memerlukan izin **Manage Channels**.');
        }
        const channel = message.mentions.channels.first() || message.channel;
        if (!channel.isTextBased() || !channel.setRateLimitPerUser || !channel.permissionOverwrites) {
            return message.reply('⚠️ Perintah ini hanya berlaku untuk channel teks.');
        }
        try {
            if (command === 'slowmode') {
                const seconds = Number(args.find(arg => /^\d+$/.test(arg)));
                if (!Number.isInteger(seconds) || seconds < 0 || seconds > 21600) return message.reply('⚠️ Gunakan `ltn slowmode [#channel] <0-21600 detik>`.');
                await channel.setRateLimitPerUser(seconds, `Diatur oleh ${message.author.tag}`);
                return message.reply(`✅ Slowmode ${channel} diatur menjadi **${seconds} detik**.`);
            }
            await channel.permissionOverwrites.edit(message.guild.roles.everyone, {
                SendMessages: command === 'unlock' ? null : false
            });
            return message.reply(command === 'lock' ? `🔒 ${channel} dikunci untuk @everyone.` : `🔓 ${channel} dibuka kembali.`);
        } catch (error) {
            console.error(`Gagal menjalankan ${command}:`, error);
            return message.reply('❌ Pengaturan channel gagal. Pastikan bot memiliki izin **Manage Channels**.');
        }
    }

    if (command === 'timeout') {
        if (!serverData || !message.member.permissions.has(PermissionsBitField.Flags.ModerateMembers)) {
            return message.reply('❌ Perintah ini memerlukan izin **Moderate Members**.');
        }
        const target = message.mentions.members.first();
        const durasi = parseDurasi(args[1]);
        const reason = args.slice(2).join(' ').slice(0, 500) || 'Tidak ada alasan';
        if (!target || !durasi || durasi > 28 * 86400000 || target.id === message.author.id || target.user.bot) {
            return message.reply('⚠️ Gunakan `ltn timeout @anggota <durasi> [alasan]` (contoh `30m`, `2h`, maksimal 28 hari).');
        }
        try {
            await target.timeout(durasi, reason);
            catatLogMod(guildId, `⏳ ${target.user.tag} di-timeout ${args[1]} oleh ${message.author.tag}. Alasan: ${reason}`, 'timeout');
            return message.reply(`✅ ${target} di-timeout selama **${args[1]}**. Alasan: ${reason}`);
        } catch (error) {
            console.error('Gagal menerapkan timeout:', error);
            return message.reply('❌ Timeout gagal. Periksa izin **Moderate Members** dan hierarki role bot.');
        }
    }

    if (command === 'modsummary') {
        if (!serverData || !message.member.permissions.has(PermissionsBitField.Flags.ManageGuild)) {
            return message.reply('❌ Perintah ini hanya untuk admin dengan izin **Manage Server**.');
        }
        const rentangLabel = args.find(arg => ['24h', '7d'].includes(arg.toLowerCase()))?.toLowerCase() || '24h';
        const kategori = args.find(arg => !['24h', '7d'].includes(arg.toLowerCase()))?.toLowerCase();
        const rentang = rentangLabel === '7d' ? 7 * 86400000 : 86400000;
        const sejak = Date.now() - rentang;
        const events = (adminLogs[guildId] || []).filter(item =>
            item.at >= sejak && (!kategori || item.type.toLowerCase() === kategori)
        );
        const counts = events.reduce((hasil, item) => {
            hasil[item.type] = (hasil[item.type] || 0) + 1;
            return hasil;
        }, {});
        const ringkasan = Object.entries(counts).map(([type, count]) => `• ${type}: **${count}**`).join('\n') || 'Belum ada aktivitas tercatat.';
        return message.reply({ embeds: [new EmbedBuilder().setColor(THEME_COLOR).setTitle(`📊 Ringkasan Moderasi (${rentangLabel === '7d' ? '7 hari' : '24 jam'})`).setDescription(`${kategori ? `Filter kategori: **${kategori}**\n` : ''}${ringkasan}\n\nTotal: **${events.length}** event.`)] });
    }

    if (command === 'backup') {
        if (!serverData || !message.member.permissions.has(PermissionsBitField.Flags.ManageGuild)) {
            return message.reply('❌ Perintah ini hanya untuk admin dengan izin **Manage Server**.');
        }
        const aksi = args[0]?.toLowerCase();
        if (!Array.isArray(adminBackups[guildId])) adminBackups[guildId] = [];
        if (aksi === 'buat') {
            const snapshot = {
                id: `${Date.now()}`,
                createdAt: Date.now(),
                settings: JSON.parse(JSON.stringify(serverData.settings)),
                filter: JSON.parse(JSON.stringify(serverData.filter)),
                voice: {
                    lobbyId: serverData.voice.lobbyId || null,
                    categoryId: serverData.voice.categoryId || null
                },
                modLogChannelId: modLogConfig[guildId] || null
            };
            adminBackups[guildId].push(snapshot);
            if (adminBackups[guildId].length > 10) adminBackups[guildId].shift();
            simpanAdminBackups();
            return message.reply(`✅ Backup konfigurasi dibuat dengan ID \`${snapshot.id}\`. Backup hanya mencakup pengaturan bot, bukan saldo/anggota.`);
        }
        if (aksi === 'daftar') {
            const list = adminBackups[guildId].map(item => `• \`${item.id}\` — <t:${Math.floor(item.createdAt / 1000)}:R>`).join('\n');
            return message.reply(list ? `📦 **Backup konfigurasi:**\n${list}` : '📦 Belum ada backup. Gunakan `ltn backup buat`.');
        }
        if (aksi === 'pulihkan') {
            const snapshot = adminBackups[guildId].find(item => item.id === args[1]);
            if (!snapshot) return message.reply('⚠️ Backup tidak ditemukan. Gunakan `ltn backup daftar`.');
            Object.assign(serverData, {
                settings: JSON.parse(JSON.stringify(snapshot.settings)),
                filter: JSON.parse(JSON.stringify(snapshot.filter)),
                voice: {
                    ...serverData.voice,
                    lobbyId: snapshot.voice.lobbyId,
                    categoryId: snapshot.voice.categoryId
                }
            });
            if (snapshot.modLogChannelId) modLogConfig[guildId] = snapshot.modLogChannelId;
            else delete modLogConfig[guildId];
            fs.writeFileSync(PATH_MOD_LOG, JSON.stringify(modLogConfig, null, 2));
            simpanOwoState();
            return message.reply(`✅ Konfigurasi dipulihkan dari backup \`${snapshot.id}\`.`);
        }
        return message.reply('⚠️ Gunakan `ltn backup buat`, `ltn backup daftar`, atau `ltn backup pulihkan <id>`.');
    }

    if (command === 'filter') {
        if (!message.guild || !message.member) {
            return message.reply('⚠️ Perintah filter hanya dapat digunakan di server Discord.');
        }
        if (!message.member.permissions.has(PermissionsBitField.Flags.ManageMessages)) {
            return message.reply('❌ Hanya pengguna dengan izin **Manage Messages** yang dapat mengelola filter.');
        }

        const aksi = args.shift()?.toLowerCase();
        const kata = args.join(' ').trim();
        const kataServer = serverData.filter.words;

        if (aksi === 'tambah') {
            const kataNormal = normalisasiTeks(kata);
            if (!kataNormal || kataNormal.length > 100) {
                return message.reply('⚠️ Masukkan kata atau frasa dengan panjang 1–100 karakter. Contoh: `ltn filter tambah kata kasar`');
            }
            if ([...filterData.globalWords, ...kataServer].some(item => normalisasiTeks(item) === kataNormal)) {
                return message.reply('ℹ️ Kata atau frasa tersebut sudah ada di filter.');
            }

            kataServer.push(kataNormal);
            simpanKataFilter();
            return message.reply(`✅ Kata/frasa **${kataNormal}** berhasil ditambahkan ke filter.`);
        }

        if (aksi === 'hapus') {
            const kataNormal = normalisasiTeks(kata);
            const index = kataServer.findIndex(item => normalisasiTeks(item) === kataNormal);
            if (!kataNormal || index === -1) {
                return message.reply('⚠️ Kata atau frasa server tidak ditemukan. Kata bawaan global tidak dapat dihapus lewat command ini.');
            }

            const [kataDihapus] = kataServer.splice(index, 1);
            simpanKataFilter();
            return message.reply(`✅ Kata/frasa **${kataDihapus}** berhasil dihapus dari filter.`);
        }

        if (aksi === 'daftar') {
            const semuaKata = [...new Set([...filterData.globalWords, ...kataServer])];
            if (semuaKata.length === 0) return message.reply('📋 Belum ada kata atau frasa di filter.');

            const daftar = semuaKata.slice(0, 50).map((item, index) => `${index + 1}. ${item}`).join('\n');
            const tambahan = semuaKata.length > 50 ? `\n...dan ${semuaKata.length - 50} lainnya.` : '';
            return message.reply(`📋 **Daftar kata/frasa filter:**\n${daftar}${tambahan}`.slice(0, 2000));
        }

        if (aksi === 'ignore-channel' || aksi === 'unignore-channel') {
            const channel = message.mentions.channels.first();
            if (!channel) return message.reply('⚠️ Sebutkan channel, contoh: `ltn filter ignore-channel #umum`.');
            const list = serverData.filter.ignoredChannels;
            const index = list.indexOf(channel.id);
            if (aksi === 'ignore-channel') {
                if (index !== -1) return message.reply('ℹ️ Channel tersebut sudah dikecualikan.');
                list.push(channel.id);
                simpanKataFilter();
                return message.reply(`✅ Filter kata dikecualikan di ${channel}.`);
            }
            if (index === -1) return message.reply('ℹ️ Channel tersebut tidak ada dalam daftar pengecualian.');
            list.splice(index, 1);
            simpanKataFilter();
            return message.reply(`✅ Pengecualian filter di ${channel} dihapus.`);
        }

        if (aksi === 'ignore-role' || aksi === 'unignore-role') {
            const role = message.mentions.roles.first();
            if (!role) return message.reply('⚠️ Sebutkan role, contoh: `ltn filter ignore-role @Moderator`.');
            const list = serverData.filter.ignoredRoles;
            const index = list.indexOf(role.id);
            if (aksi === 'ignore-role') {
                if (index !== -1) return message.reply('ℹ️ Role tersebut sudah dikecualikan.');
                list.push(role.id);
                simpanKataFilter();
                return message.reply(`✅ Anggota dengan role ${role} dikecualikan dari filter kata.`);
            }
            if (index === -1) return message.reply('ℹ️ Role tersebut tidak ada dalam daftar pengecualian.');
            list.splice(index, 1);
            simpanKataFilter();
            return message.reply(`✅ Pengecualian filter untuk role ${role} dihapus.`);
        }

        return message.reply('⚠️ Gunakan `ltn filter tambah/hapus/daftar`, `ignore-channel #channel`, atau `ignore-role @role` (gunakan `unignore-...` untuk membatalkan).');
    }

    if (serverData && message.member &&
        !serverData.filter.ignoredChannels.includes(message.channel.id) &&
        !message.member.roles.cache.some(role => serverData.filter.ignoredRoles.includes(role.id))) {
        const kataFilter = [...filterData.globalWords, ...serverData.filter.words];
        const teksPesan = ` ${normalisasiTeks(message.content)} `;
        const terdeteksi = kataFilter.some(kata => {
            const kataNormal = normalisasiTeks(kata);
            return kataNormal && teksPesan.includes(` ${kataNormal} `);
        });

        if (terdeteksi) {
            try {
                await message.delete();
                catatLogMod(guildId, `🧹 Pesan dari ${message.author.tag} dihapus oleh filter di ${message.channel}.`, 'filter');
            } catch (error) {
                console.error('Gagal menghapus pesan yang melanggar filter:', error);
                return message.reply('⚠️ Pesan terdeteksi oleh filter, tetapi bot gagal menghapusnya. Periksa izin **Manage Messages** bot.')
                    .catch(replyError => console.error('Gagal mengirim peringatan filter:', replyError));
            }

            try {
                const peringatan = await message.channel.send(`${message.author}, pesanmu dihapus karena mengandung kata atau frasa yang difilter.`);
                setTimeout(() => peringatan.delete().catch(error => {
                    console.error('Gagal menghapus pesan peringatan filter:', error);
                }), 5000);
            } catch (error) {
                console.error('Gagal mengirim peringatan filter:', error);
            }
            return;
        }
    }

    if (!isCommand && serverData) {
        const autoResponses = ambilPengaturanAutoRespons(serverData);
        const aturan = serverData.settings.autoResponsesEnabled
            ? autoResponses.find(item => item && typeof item.trigger === 'string' && pesanMengandungPemicu(message.content, item.trigger))
            : null;
        if (aturan && typeof aturan.response === 'string' && aturan.response.trim()) {
            try {
                await message.channel.send({
                    content: aturan.response.slice(0, 1800),
                    allowedMentions: { parse: [] }
                });
            } catch (error) {
                console.error('Gagal mengirim balasan otomatis:', error);
            }
        }
    }

    if (serverData) {
        const xpPemain = ambilDataPemain(serverData, message.author.id, guildId);
        await berikanXP(message, xpPemain);
    }
    if (!isCommand) return;
    if (!serverData) return message.reply('⚠️ Perintah bot hanya dapat digunakan di server Discord.');

    const uangData = economyData.servers[guildId];
    const userId = message.author.id;
    const statePemain = ambilDataPemain(serverData, userId, guildId);

    if (['autorespon', 'auto-respon', 'autoresponse'].includes(command)) {
        if (!message.member.permissions.has(PermissionsBitField.Flags.ManageGuild)) {
            return message.reply('❌ Pengaturan auto-respon hanya dapat digunakan admin dengan izin **Manage Server**.');
        }
        const aturan = ambilPengaturanAutoRespons(serverData);
        const aksi = args[0]?.toLowerCase();
        const isiAksi = message.content.slice(PREFIX.length + command.length).trim().replace(/^\S+\s*/, '');

        if (aksi === 'tambah' || aksi === 'add') {
            const pemisah = isiAksi.indexOf('|');
            if (pemisah < 0) {
                return message.reply('⚠️ Format: `ltn autorespon tambah <kata> | <balasan>`\nContoh: `ltn autorespon tambah hi | hallo!`');
            }
            const triggerAsli = isiAksi.slice(0, pemisah).trim();
            const response = isiAksi.slice(pemisah + 1).trim();
            const trigger = normalisasiTeks(triggerAsli);
            if (!trigger || triggerAsli.length > 80 || triggerAsli.toLowerCase().startsWith(PREFIX)) {
                return message.reply('⚠️ Kata pemicu harus 1–80 karakter dan bukan command bot.');
            }
            if (!response || response.length > 1800) {
                return message.reply('⚠️ Balasan harus berisi 1–1.800 karakter.');
            }
            if (aturan.some(item => item && normalisasiTeks(item.trigger || '') === trigger)) {
                return message.reply('ℹ️ Kata atau frasa pemicu tersebut sudah terdaftar.');
            }
            if (aturan.length >= 50) {
                return message.reply('⚠️ Batas auto-respon adalah 50 aturan per server. Hapus aturan lama terlebih dahulu.');
            }
            aturan.push({ trigger: triggerAsli, response });
            serverData.settings.autoResponsesEnabled = true;
            simpanOwoState();
            return message.reply(`✅ Auto-respon ditambahkan: **${amanUntukTeksDiscord(triggerAsli)}** → balasan siap digunakan.`);
        }

        if (aksi === 'hapus' || aksi === 'remove') {
            const pemicu = normalisasiTeks(isiAksi);
            const index = aturan.findIndex(item => item && normalisasiTeks(item.trigger || '') === pemicu);
            if (!pemicu || index < 0) return message.reply('⚠️ Pemicu tidak ditemukan. Gunakan `ltn autorespon daftar` untuk melihat aturan.');
            const [dihapus] = aturan.splice(index, 1);
            simpanOwoState();
            return message.reply(`✅ Auto-respon **${amanUntukTeksDiscord(dihapus.trigger)}** dihapus.`);
        }

        if (aksi === 'daftar' || aksi === 'list') {
            if (!aturan.length) return message.reply('📋 Belum ada auto-respon. Tambahkan dengan `ltn autorespon tambah <kata> | <balasan>`.');
            const daftar = aturan.slice(0, 25).map((item, index) =>
                `${index + 1}. **${amanUntukTeksDiscord(item.trigger)}** → ${amanUntukTeksDiscord(item.response)}`
            ).join('\n');
            const status = serverData.settings.autoResponsesEnabled ? 'Aktif' : 'Nonaktif';
            return message.reply(`🤖 **Auto-respon • ${status}**\n${daftar}${aturan.length > 25 ? `\n...dan ${aturan.length - 25} aturan lainnya.` : ''}`.slice(0, 1900));
        }

        if (aksi === 'aktif' || aksi === 'on') {
            serverData.settings.autoResponsesEnabled = true;
            simpanOwoState();
            return message.reply('✅ Auto-respon diaktifkan.');
        }

        if (aksi === 'nonaktif' || aksi === 'off') {
            serverData.settings.autoResponsesEnabled = false;
            simpanOwoState();
            return message.reply('⏸️ Auto-respon dinonaktifkan. Aturan yang tersimpan tidak dihapus.');
        }

        return message.reply('⚠️ Perintah: `ltn autorespon tambah <kata> | <balasan>`, `hapus <kata>`, `daftar`, `aktif`, atau `nonaktif`.');
    }

    if (command === 'economy' || command === 'ekonomi') {
        if (!message.member.permissions.has(PermissionsBitField.Flags.ManageGuild)) {
            return message.reply('❌ Hanya admin dengan izin **Manage Server** yang dapat mengatur ekonomi.');
        }
        const aksi = args[0]?.toLowerCase();
        if (aksi === 'set' && args[1]?.toLowerCase() === 'daily') {
            const hadiah = Number(args[2]);
            if (!Number.isSafeInteger(hadiah) || hadiah < 0 || hadiah > 1000000000) {
                return message.reply('⚠️ Hadiah daily harus angka 0–1.000.000.000.');
            }
            serverData.settings.dailyReward = hadiah;
            simpanOwoState();
            return message.reply(`✅ Hadiah daily server diatur menjadi **${formatUang(hadiah)} koin**.`);
        }
        if (aksi === 'set' && args[1]?.toLowerCase() === 'start') {
            const saldoAwal = Number(args[2]);
            if (!Number.isSafeInteger(saldoAwal) || saldoAwal < 0 || saldoAwal > 1000000000) {
                return message.reply('⚠️ Saldo awal harus angka 0–1.000.000.000.');
            }
            serverData.settings.startingBalance = saldoAwal;
            simpanOwoState();
            return message.reply(`✅ Saldo awal pemain baru diatur menjadi **${formatUang(saldoAwal)} koin**.`);
        }
        return message.reply(`⚙️ Pengaturan ekonomi:\nDaily: **${formatUang(serverData.settings.dailyReward)} koin**\nSaldo awal: **${formatUang(serverData.settings.startingBalance)} koin**\nGunakan \`ltn economy set daily <jumlah>\` atau \`ltn economy set start <jumlah>\`.`);
    }

    // Perintah !kick @user
    if (command === 'kick') {
        if (!message.member.permissions.has(PermissionsBitField.Flags.KickMembers)) return message.reply('❌ Izin ditolak.');
        const target = message.mentions.members.first();
        if (!target) return message.reply('⚠️ Sebutkan (mention) orang yang ingin di-kick!');
        try {
            await target.kick();
            message.reply(`✅ Berhasil mengeluarkan ${target.user.tag}.`);
            catatLogMod(guildId, `👢 ${message.author.tag} mengeluarkan ${target.user.tag} dari server.`, 'kick');
        } catch (error) {
            message.reply('❌ Gagal. Pastikan role bot lebih tinggi dari target.');
        }
    }

    // Perintah !clear 10
    if (command === 'clear') {
        if (!message.member.permissions.has(PermissionsBitField.Flags.ManageMessages)) return message.reply('❌ Izin ditolak.');
        const amount = parseInt(args[0]);
        if (isNaN(amount) || amount < 1 || amount > 100) return message.reply('⚠️ Masukkan angka 1 - 100.');
        await message.channel.bulkDelete(amount, true);
        message.channel.send(`✅ Menghapus ${amount} pesan.`).then(msg => setTimeout(() => msg.delete(), 3000));
        catatLogMod(guildId, `🧹 ${message.author.tag} menghapus ${amount} pesan di ${message.channel}.`, 'clear');
    }

    if (command === 'vc') {
        const aksi = args.shift()?.toLowerCase();
        const mentionChannels = [...message.mentions.channels.values()];
        if (!serverData || !message.member) {
            return message.reply('❌ Command voice hanya dapat digunakan di dalam server Discord.');
        }

        if (aksi === 'setup') {
            if (!message.member.permissions.has(PermissionsBitField.Flags.ManageChannels)) {
                return message.reply('❌ Pengaturan lobby voice memerlukan izin **Manage Channels**.');
            }
            const lobby = mentionChannels[0] || message.member.voice.channel;
            if (!lobby || ![ChannelType.GuildVoice, ChannelType.GuildStageVoice].includes(lobby.type)) {
                return message.reply('⚠️ Sebutkan lobby voice atau masuk ke channel voice lalu gunakan `ltn vc setup`.');
            }
            serverData.voice.lobbyId = lobby.id;
            serverData.voice.categoryId = lobby.parentId || null;
            simpanOwoState();
            return message.reply(`✅ Lobby voice sementara diatur ke **${lobby.name}**. Anggota yang masuk akan dibuatkan channel voice otomatis.`);
        }

        if (aksi === 'panel' && (args[0]?.toLowerCase() === 'off' || args[0]?.toLowerCase() === 'setup' || mentionChannels.length > 0)) {
            if (!message.member.permissions.has(PermissionsBitField.Flags.ManageGuild)) {
                return message.reply('❌ Mengatur panel voice bersama memerlukan izin **Manage Server**.');
            }
            if (args[0]?.toLowerCase() === 'off') {
                delete serverData.voice.panelChannelId;
                delete serverData.voice.panelMessageId;
                simpanOwoState();
                return message.reply('✅ Panel voice bersama dinonaktifkan. Panel lama tidak lagi dapat menjalankan aksi.');
            }
            const channel = mentionChannels.find(item => item.type === ChannelType.GuildText || item.type === ChannelType.GuildAnnouncement);
            if (!channel || !channel.isTextBased() || typeof channel.send !== 'function') {
                return message.reply('⚠️ Sebutkan channel teks. Contoh: `ltn vc panel #voice-panel` atau `ltn vc panel setup #voice-panel`.');
            }
            try {
                let panelMessage = null;
                if (serverData.voice.panelChannelId === channel.id && serverData.voice.panelMessageId) {
                    try {
                        panelMessage = await channel.messages.fetch(serverData.voice.panelMessageId);
                    } catch (error) {
                        console.error('Panel voice bersama sebelumnya tidak dapat ditemukan; membuat panel baru:', error);
                    }
                }
                const panelPayload = {
                    content: '',
                    ...buatPanelVoiceBersama(guildId)
                };
                if (panelMessage) await panelMessage.edit(panelPayload);
                else panelMessage = await channel.send(panelPayload);
                serverData.voice.panelChannelId = channel.id;
                serverData.voice.panelMessageId = panelMessage.id;
                simpanOwoState();
                return message.reply(`✅ Panel voice bersama berhasil dikirim atau diperbarui di ${channel}.`);
            } catch (error) {
                console.error('Gagal mengirim atau memperbarui panel voice bersama:', error);
                return message.reply('❌ Panel gagal dikirim. Pastikan bot memiliki izin **View Channel**, **Send Messages**, dan **Embed Links** di channel tujuan.');
            }
        }

        if (aksi === 'owner' || aksi === 'pemilik') {
            const voice = message.member.voice.channel;
            if (!voice) return message.reply('⚠️ Masuk ke voice channel untuk melihat pemiliknya.');
            const ownerId = serverData.voice.rooms[voice.id];
            if (!ownerId) return message.reply('ℹ️ Voice channel ini bukan channel sementara yang dikelola bot.');
            return message.reply(`👑 Pemilik **${voice.name}** adalah <@${ownerId}>.`);
        }

        const voice = message.member.voice.channel;
        if (!voice) return message.reply('⚠️ Masuk ke voice channel milikmu untuk memakai pengaturan voice.');
        const pemilikId = serverData.voice.rooms[voice.id];
        if (!pemilikId) return message.reply('ℹ️ Command ini hanya berlaku di voice sementara yang dibuat bot.');
        if (aksi === 'panel') {
            if (pemilikId !== message.author.id) {
                return message.reply(`❌ Hanya pemilik channel (<@${pemilikId}>) yang dapat menampilkan panel.`);
            }
            try {
                await voice.send({
                    content: `${message.author}, berikut panel pengaturan untuk voice sementara milikmu:`,
                    ...buatPanelVoice(voice, pemilikId)
                });
                return message.reply(`✅ Panel pengaturan berhasil dikirim ke chat **${voice.name}**.`);
            } catch (error) {
                console.error('Gagal mengirim panel voice melalui command:', error);
                return message.reply('❌ Panel gagal dikirim ke chat voice. Pastikan bot memiliki izin **View Channel** dan **Send Messages** di voice channel tersebut.');
            }
        }
        if (pemilikId !== message.author.id) return message.reply(`❌ Hanya pemilik channel (<@${pemilikId}>) yang dapat mengubah pengaturannya.`);

        try {
            if (aksi === 'lock') {
                await voice.permissionOverwrites.edit(message.guild.roles.everyone, { Connect: false });
                return message.reply(`🔒 **${voice.name}** dikunci. Anggota lain tidak dapat bergabung.`);
            }
            if (aksi === 'unlock') {
                await voice.permissionOverwrites.edit(message.guild.roles.everyone, { Connect: null });
                await voice.permissionOverwrites.edit(message.author.id, { ViewChannel: true, Connect: true, Speak: true });
                return message.reply(`🔓 **${voice.name}** dibuka kembali.`);
            }
            if (aksi === 'limit') {
                const limit = Number(args[0]);
                if (!Number.isInteger(limit) || limit < 0 || limit > 99) {
                    return message.reply('⚠️ Batas anggota harus 0–99. Gunakan `0` untuk tanpa batas.');
                }
                await voice.setUserLimit(limit);
                return message.reply(`✅ Batas anggota **${voice.name}** diatur ke **${limit === 0 ? 'tanpa batas' : limit}**.`);
            }
            if (aksi === 'name') {
                const nama = args.join(' ').trim();
                if (!nama || nama.length > 100) return message.reply('⚠️ Masukkan nama channel dengan panjang 1–100 karakter.');
                await voice.setName(nama);
                return message.reply(`✅ Nama voice channel diubah menjadi **${nama}**.`);
            }
            if (aksi === 'transfer') {
                const target = message.mentions.members.first();
                if (!target || target.user.bot || target.id === message.author.id || target.voice.channelId !== voice.id) {
                    return message.reply('⚠️ Sebutkan anggota lain yang sedang berada di voice channel ini.');
                }
                await voice.permissionOverwrites.edit(target.id, { ViewChannel: true, Connect: true, Speak: true });
                await voice.permissionOverwrites.edit(pemilikId, { ViewChannel: null, Connect: null, Speak: null });
                serverData.voice.rooms[voice.id] = target.id;
                simpanOwoState();
                return message.reply(`👑 Kepemilikan **${voice.name}** dipindahkan ke ${target}.`);
            }
            if (aksi === 'kick') {
                const target = message.mentions.members.first();
                if (!target || target.user.bot || target.id === message.author.id || target.voice.channelId !== voice.id) {
                    return message.reply('⚠️ Sebutkan anggota lain yang sedang berada di voice channel ini.');
                }
                await target.voice.disconnect('Dikeluarkan oleh pemilik voice sementara');
                return message.reply(`🔌 ${target.user.tag} dikeluarkan dari **${voice.name}**.`);
            }
        } catch (error) {
            console.error(`Gagal menjalankan command vc ${aksi}:`, error);
            return message.reply('❌ Command voice gagal. Pastikan bot memiliki izin **Manage Channels** dan **Move Members**.');
        }

        return message.reply('⚠️ Command: `ltn vc setup`, `owner`, `panel [#channel|off]`, `lock`, `unlock`, `limit <0-99>`, `name <nama>`, `transfer @user`, atau `kick @user`.');
    }

    // Perintah !mutevc
    if (command === 'mutevc') {
        const voiceChannel = message.member.voice.channel;
        if (!voiceChannel) return message.reply('⚠️ Anda harus berada di Voice Channel!');
        const pemilikVoice = serverData.voice.rooms[voiceChannel.id] === message.author.id;
        if (!pemilikVoice && !message.member.permissions.has(PermissionsBitField.Flags.MuteMembers)) {
            return message.reply('❌ Perintah ini memerlukan izin **Mute Members** atau kepemilikan voice sementara.');
        }
        for (const [memberID, member] of voiceChannel.members) {
            if (!member.user.bot) await member.voice.setMute(true);
        }
        message.reply(`🔇 Semua anggota di **${voiceChannel.name}** di-mute.`);
        catatLogMod(guildId, `🔇 ${message.author.tag} mute semua anggota di ${voiceChannel.name}.`, 'mutevc');
    }

    // Perintah !unmutevc
    if (command === 'unmutevc') {
        const voiceChannel = message.member.voice.channel;
        if (!voiceChannel) return message.reply('⚠️ Anda harus berada di Voice Channel!');
        const pemilikVoice = serverData.voice.rooms[voiceChannel.id] === message.author.id;
        if (!pemilikVoice && !message.member.permissions.has(PermissionsBitField.Flags.MuteMembers)) {
            return message.reply('❌ Perintah ini memerlukan izin **Mute Members** atau kepemilikan voice sementara.');
        }
        for (const [memberID, member] of voiceChannel.members) {
            await member.voice.setMute(false);
        }
        message.reply(`🔊 Mute dibuka untuk **${voiceChannel.name}**.`);
        catatLogMod(guildId, `🔊 ${message.author.tag} unmute anggota di ${voiceChannel.name}.`, 'unmutevc');
    }

    // Perintah !dc @user
    if (command === 'dc') {
        const target = message.mentions.members.first();
        if (!target || !target.voice.channel) return message.reply('⚠️ Target tidak ada di Voice Channel.');
        const voicePemilik = message.member.voice.channel;
        const pemilikBolehDisconnect = voicePemilik &&
            voicePemilik.id === target.voice.channelId &&
            serverData.voice.rooms[voicePemilik.id] === message.author.id;
        if (!pemilikBolehDisconnect && !message.member.permissions.has(PermissionsBitField.Flags.MoveMembers)) {
            return message.reply('❌ Perintah ini memerlukan izin **Move Members** atau kepemilikan voice sementara.');
        }
        await target.voice.disconnect();
        message.reply(`🔌 ${target.user.tag} diputus dari obrolan suara.`);
        catatLogMod(guildId, `🔌 ${message.author.tag} disconnect ${target.user.tag} dari voice channel.`, 'dc');
    }
    
    // ==========================================
    // EKONOMI COWONCY & MINI-GAMES
    // ==========================================
    if (command === 'top' || command === 'leaderboard') {
        const pemainTeratas = Object.entries(uangData)
            .filter(([id, saldo]) => /^\d{17,20}$/.test(id) && Number.isSafeInteger(saldo) && saldo >= 0)
            .sort((a, b) => b[1] - a[1]);

        if (pemainTeratas.length === 0) return message.reply('📊 Belum ada data saldo untuk ditampilkan.');

        const pemilik = message.author.id;
        const halaman = (indeks) => {
            const potongan = pemainTeratas.slice(indeks * 10, indeks * 10 + 10);
            const daftarTop = potongan.map(([id, saldo], posisi) => {
                const rank = indeks * 10 + posisi;
                const medali = ['🥇', '🥈', '🥉'];
                return `${medali[rank] || `**${rank + 1}.**`} <@${id}> — **${formatUang(saldo)} koin**`;
            }).join('\n');
            return new EmbedBuilder()
                .setColor(THEME_COLOR)
                .setTitle('🏆 Pemain Terkaya di Server')
                .setDescription(daftarTop)
                .setFooter({ text: `Halaman ${indeks + 1}/${Math.ceil(pemainTeratas.length / 10)}` })
                .setTimestamp();
        };
        const jumlahHalaman = Math.ceil(pemainTeratas.length / 10);
        const buatNavigasi = indeks => new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('top-prev').setLabel('Sebelumnya').setStyle(ButtonStyle.Secondary).setDisabled(indeks === 0),
            new ButtonBuilder().setCustomId('top-next').setLabel('Berikutnya').setStyle(ButtonStyle.Primary).setDisabled(indeks >= jumlahHalaman - 1)
        );
        const balasanTop = await message.reply({
            embeds: [halaman(0)],
            components: [buatNavigasi(0)],
            allowedMentions: { parse: [] }
        });
        const collector = balasanTop.createMessageComponentCollector({ time: 120000 });
        let halamanAktif = 0;
        collector.on('collect', async interaction => {
            if (interaction.user.id !== pemilik) {
                await interaction.reply({ content: 'Leaderboard ini dibuka oleh pemain lain.', ephemeral: true });
                return;
            }
            halamanAktif += interaction.customId === 'top-next' ? 1 : -1;
            await interaction.update({
                embeds: [halaman(halamanAktif)],
                components: [buatNavigasi(halamanAktif)]
            });
        });
        collector.on('end', () => balasanTop.edit({ components: [] }).catch(error => {
            console.error('Gagal menonaktifkan tombol leaderboard:', error);
        }));
        return;
    }

    if (command === 'profile' || command === 'profil') {
        const target = message.mentions.members.first() || message.member;
        if (target.id === message.author.id) {
            return message.reply({
                content: '📊 Buka profil privatmu untuk melihat saldo, daily, level, zoo, dan inventory dalam satu dashboard.',
                components: [new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setCustomId(`dashboard-open:${message.author.id}:${guildId}`)
                        .setLabel('Buka Dashboard Privat')
                        .setEmoji('📊')
                        .setStyle(ButtonStyle.Primary)
                )]
            });
        }
        const pemain = ambilDataPemain(serverData, target.id, guildId);
        const saldo = uangData[target.id] || 0;
        const progres = Math.min(20, Math.floor((pemain.xp / xpUntukLevel(pemain.level)) * 20));
        const barXp = `${'🟩'.repeat(progres)}${'⬛'.repeat(20 - progres)}`;
        const embed = new EmbedBuilder()
            .setColor(THEME_COLOR)
            .setTitle(`👤 Profil ${target.displayName}`)
            .setThumbnail(target.user.displayAvatarURL({ size: 512 }))
            .addFields(
                { name: 'Level', value: `**${pemain.level}**`, inline: true },
                { name: 'Koin', value: `**${formatUang(saldo)}**`, inline: true },
                { name: 'Hewan', value: `**${Object.values(pemain.zoo).reduce((total, jumlah) => total + (Number.isSafeInteger(jumlah) && jumlah > 0 ? jumlah : 0), 0)}**`, inline: true },
                { name: 'EXP', value: `${barXp}\n**${formatUang(pemain.xp)} / ${formatUang(xpUntukLevel(pemain.level))} EXP**` },
                { name: 'Statistik aktivitas', value: `Pesan aktif: **${pemain.stats.messages || 0}** | Permainan: **${pemain.stats.games || 0}** | Berburu: **${pemain.stats.hunts || 0}** | Streak daily: **${pemain.dailyStreak || 0} hari**` }
            )
            .setTimestamp();
        return message.reply({ embeds: [embed] });
    }

    if (command === 'history' || command === 'riwayat') {
        const target = message.mentions.members.first() || message.member;
        const pemain = ambilDataPemain(serverData, target.id, guildId);
        const riwayat = pemain.history.slice(-10).reverse();
        if (riwayat.length === 0) return message.reply('📜 Belum ada riwayat transaksi atau permainan.');
        const barisRiwayat = riwayat.map(item => {
            const tanggal = new Date(item.at).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });
            const nominal = item.amount === null ? '' : ` — ${formatUang(Math.abs(item.amount))} koin`;
            return `• \`${tanggal}\` **${item.type}**${nominal}${item.detail ? ` (${item.detail})` : ''}`;
        }).join('\n');
        return message.reply(`📜 **10 riwayat terbaru ${target.displayName}**\n${barisRiwayat}`.slice(0, 2000));
    }
    if (command === 'cash' || command === 'bal' || command === 'saldo') {
        return message.reply(`💰 Saldo koin kamu: **${formatUang(uangData[userId])} koin**.`);
    }

    if (command === 'daily') {
        const hasilDaily = klaimDaily(serverData, statePemain, uangData, userId);
        if (!hasilDaily.ok) {
            const jam = Math.floor(hasilDaily.sisaCooldown / (60 * 60 * 1000));
            const menit = Math.ceil((hasilDaily.sisaCooldown % (60 * 60 * 1000)) / (60 * 1000));
            return message.reply(`⏳ Kamu sudah mengambil daily. Coba lagi dalam **${jam} jam ${menit} menit**.`);
        }
        return message.reply(`🎁 Daily streak **${hasilDaily.streak} hari**! Kamu mendapatkan **${formatUang(hasilDaily.hadiah)} koin**. Saldo sekarang: **${formatUang(hasilDaily.saldo)} koin**.`);
    }

    if (command === 'send' || command === 'pay' || command === 'transfer') {
        const target = message.mentions.members.first();
        const jumlah = parseJumlah(args[1], uangData[userId]);

        if (!target) return message.reply('⚠️ Sebutkan pemain yang ingin kamu beri koin. Contoh: `ltn send @user 1.000`');
        if (target.id === userId) return message.reply('❌ Kamu tidak bisa mengirim koin ke diri sendiri.');
        if (target.user.bot) return message.reply('❌ Kamu tidak bisa mengirim koin ke bot.');
        if (!jumlah) return message.reply('⚠️ Masukkan jumlah positif, format titik ribuan, atau `all`.');
        if (uangData[userId] < jumlah) return message.reply('❌ Saldo koin kamu tidak cukup untuk transfer ini.');

        const statePenerima = ambilDataPemain(serverData, target.id, guildId);
        uangData[userId] -= jumlah;
        uangData[target.id] += jumlah;
        simpanRiwayat(statePemain, 'transfer keluar', -jumlah, `ke ${target.user.tag}`);
        simpanRiwayat(statePenerima, 'transfer masuk', jumlah, `dari ${message.author.tag}`);
        simpanUang();
        simpanOwoState();
        return message.reply(`💸 Berhasil mengirim **${formatUang(jumlah)} koin** kepada **${target.user.tag}**.`);
    }

    if (command === 'pray' || command === 'curse') {
        const target = message.mentions.members.first();
        if (!target) return message.reply(`⚠️ Sebutkan pemain yang ingin kamu ${command === 'pray' ? 'doakan' : 'kutuk'}.`);
        if (target.id === userId) return message.reply('😅 Kamu tidak bisa memilih dirimu sendiri.');
        if (target.user.bot) return message.reply('🤖 Pilih pemain sungguhan, bukan bot.');
        const sisaCooldown = 30000 - (Date.now() - (statePemain.lastPrayCurse || 0));
        if (sisaCooldown > 0) return message.reply(`⏳ Tunggu **${Math.ceil(sisaCooldown / 1000)} detik** sebelum menggunakan pray/curse lagi.`);
        statePemain.lastPrayCurse = Date.now();
        simpanOwoState();
        const pesan = command === 'pray'
            ? [`🙏 ${message.author} mendoakan ${target}. Semoga harimu penuh keberuntungan!`, `✨ Doa ${message.author} terkirim untuk ${target}. Semoga semua urusanmu lancar!`, `🌟 ${target} mendapat doa baik dari ${message.author}!`]
            : [`🌩️ ${message.author} mengirim kutukan bercanda kepada ${target}. Semoga sandalmu selalu hilang sebelah!`, `🌀 ${message.author} mengirim kutukan ringan kepada ${target}. Hati-hati dengan dadu hari ini!`, `🌧️ Awan sial sebentar menaungi ${target}, atas ulah ${message.author}!`];
        return message.channel.send(pesan[Math.floor(Math.random() * pesan.length)]);
    }

    if (command === 'shop' || command === 'toko') {
        const daftarBarang = Object.entries(ITEM_TOKO)
            .map(([id, item]) => `• **${id}** — ${formatUang(item.harga)} koin\n  ${item.deskripsi}`)
            .join('\n');
        return message.reply(`🛒 **TOKO SERVER**\n${daftarBarang}\nBeli dengan \`ltn buy <barang> [jumlah]\`.`);
    }

    if (command === 'buy' || command === 'beli') {
        const idItem = args[0]?.toLowerCase();
        const item = ITEM_TOKO[idItem];
        const jumlah = args[1] === undefined ? 1 : Number(args[1]);
        if (!item) return message.reply('⚠️ Barang tidak ditemukan. Gunakan `ltn shop` untuk melihat toko.');
        if (!Number.isSafeInteger(jumlah) || jumlah < 1 || jumlah > 100) {
            return message.reply('⚠️ Jumlah pembelian harus 1–100.');
        }
        const totalHarga = item.harga * jumlah;
        if (uangData[userId] < totalHarga) return message.reply(`❌ Koin tidak cukup. Harga total: **${formatUang(totalHarga)} koin**.`);
        uangData[userId] -= totalHarga;
        statePemain.inventory[idItem] = (statePemain.inventory[idItem] || 0) + jumlah;
        simpanRiwayat(statePemain, 'pembelian', -totalHarga, `${item.nama} ×${jumlah}`);
        simpanUang();
        simpanOwoState();
        return message.reply(`✅ Membeli **${item.nama} ×${jumlah}** seharga **${formatUang(totalHarga)} koin**.`);
    }

    if (command === 'inventory' || command === 'inv' || command === 'tas') {
        const items = Object.entries(statePemain.inventory).filter(([, jumlah]) => jumlah > 0);
        if (items.length === 0) return message.reply('🎒 Inventory kamu kosong. Cek `ltn shop` untuk membeli item.');
        return message.reply(`🎒 **INVENTORY ${message.author.username}**\n${items.map(([id, jumlah]) => `• **${ITEM_TOKO[id]?.nama || id}** ×${formatUang(jumlah)}`).join('\n')}`);
    }

    if (command === 'use' || command === 'pakai') {
        const idItem = args[0]?.toLowerCase();
        if (idItem !== 'umpan') return message.reply('⚠️ Item itu tidak bisa digunakan. Item yang tersedia: `umpan`.');
        if ((statePemain.inventory.umpan || 0) < 1) return message.reply('❌ Kamu tidak punya umpan. Beli di `ltn shop`.');
        if (statePemain.huntBoost) return message.reply('ℹ️ Umpanmu sudah aktif untuk perburuan berikutnya.');
        statePemain.inventory.umpan--;
        statePemain.huntBoost = true;
        simpanOwoState();
        return message.reply('🪤 Umpan hoki dipasang. Peluang hewan langka meningkat pada perburuan berikutnya.');
    }

    if (command === 'hunt') {
        const hasilHunt = berburu(serverData, statePemain, guildId, userId);
        if (!hasilHunt.ok) return message.reply(`⏳ Kamu perlu istirahat **${Math.ceil(hasilHunt.sisaCooldown / 1000)} detik** sebelum berburu lagi.`);
        return message.reply({
            content: `🏹 Kamu berburu dan mendapatkan **${hasilHunt.hewan.nama}**! Kelangkaan: **${hasilHunt.hewan.kelangkaan}**.${hasilHunt.pakaiUmpan ? ' 🪤 Umpan hoki digunakan.' : ''} Nilai jual: **${formatUang(hasilHunt.hewan.nilai)} koin**.`,
            components: tombolMainLagi(userId, 'hunt', 0)
        });
    }

    if (command === 'zoo') {
        const koleksi = Object.entries(statePemain.zoo).filter(([, jumlah]) => Number.isSafeInteger(jumlah) && jumlah > 0);
        if (koleksi.length === 0) return message.reply('🦒 Zoo kamu masih kosong. Ketik `ltn hunt` untuk berburu!');
        const isiZoo = koleksi.map(([nama, jumlah]) => {
            const hewan = HEWAN.find(item => item.nama === nama);
            return `• **${nama}** ×${formatUang(jumlah)}${hewan ? ` — ${hewan.kelangkaan}` : ''}`;
        }).join('\n');
        return message.reply(`🦒 **Zoo milik ${message.author.username}**\n${isiZoo}`);
    }

    if (command === 'sell') {
        if (args[0]?.toLowerCase() !== 'all') return message.reply('⚠️ Gunakan `ltn sell all` untuk menjual seluruh hewan di zoo.');
        const hasilJual = jualZoo(statePemain, uangData, userId);
        if (!hasilJual.ok) {
            if (hasilJual.reason === 'saldo_limit') return message.reply('⚠️ Saldo setelah penjualan melewati batas aman; tidak ada hewan yang dijual.');
            if (hasilJual.reason === 'overflow') return message.reply('⚠️ Nilai zoo melewati batas aman; tidak ada hewan yang dijual.');
            return message.reply('🦒 Tidak ada hewan yang bisa dijual.');
        }
        return message.reply(`💰 Berhasil menjual **${formatUang(hasilJual.hewanTerjual)} hewan** seharga **${formatUang(hasilJual.hasilJual)} koin**.`);
    }

    if (command === 'cf' || command === 'coinflip') {
        const tebakan = args[0]?.toLowerCase();
        const taruhan = parseJumlah(args[1], uangData[userId]);
        if (!['head', 'tail'].includes(tebakan)) return message.reply('⚠️ Pilih `head` atau `tail`. Contoh: `ltn cf head 1.000`');
        if (!taruhan) return message.reply('⚠️ Masukkan taruhan positif atau `all`.');
        if (uangData[userId] < taruhan) return message.reply('❌ Koin kamu tidak cukup.');
        if (!Number.isSafeInteger(uangData[userId] + taruhan)) {
            return message.reply('⚠️ Saldo terlalu besar untuk memproses taruhan dengan aman.');
        }
        const cooldown = mulaiCooldownGame(statePemain, 'cf', 10000);
        if (cooldown > 0) return message.reply(`⏳ Coinflip bisa dimainkan lagi <t:${Math.ceil((Date.now() + cooldown) / 1000)}:R>.`);

        uangData[userId] -= taruhan;
        simpanUang();
        let taruhanDiselesaikan = false;
        try {
            const pesanKoin = await message.reply(`🪙 **COINFLIP**\nTaruhan dicadangkan: **${formatUang(taruhan)} koin**\nKoin dilempar...`);
            const bingkaiKoin = ['⚪', '🟡', '⚪', '🟡', '⚪'];
            for (const bingkai of bingkaiKoin) {
                await jeda(400);
                await pesanKoin.edit(`🪙 **COINFLIP**\nTaruhan: **${formatUang(taruhan)} koin**\n${bingkai} Koin berputar...`);
            }

            const hasilAcak = Math.random() < 0.5 ? 'head' : 'tail';
            const menang = tebakan === hasilAcak;
            const perubahanSaldo = menang ? taruhan : -taruhan;
            if (menang) uangData[userId] += taruhan;
            statePemain.stats.games = (statePemain.stats.games || 0) + 1;
            simpanRiwayat(statePemain, 'coinflip', perubahanSaldo, hasilAcak);
            simpanUang();
            simpanOwoState();
            taruhanDiselesaikan = true;
            const hasil = menang
                ? `🎉 Kamu menang **${formatUang(taruhan)} koin**!`
                : `💀 Kamu kalah **${formatUang(taruhan)} koin**.`;
            return await pesanKoin.edit({
                content: `🪙 **COINFLIP**\nHasil lemparan: **${hasilAcak.toUpperCase()}**.\n${hasil}\nSaldo: **${formatUang(uangData[userId])} koin**.`,
                components: tombolMainLagi(userId, 'cf', taruhan, tebakan)
            });
        } catch (error) {
            if (!taruhanDiselesaikan) {
                uangData[userId] += taruhan;
                simpanUang();
            }
            console.error('Gagal memproses coinflip:', error);
            return message.reply(taruhanDiselesaikan
                ? '⚠️ Hasil coinflip sudah diproses dan saldo tersimpan, tetapi pesan hasil gagal diperbarui.'
                : '⚠️ Coinflip gagal diproses; taruhan sudah dikembalikan.')
                .catch(replyError => console.error('Gagal memberi tahu pemain tentang coinflip:', replyError));
        }
    }

    if (command === 'slot') {
        const taruhan = parseJumlah(args[0], uangData[userId]);
        if (!taruhan) return message.reply('⚠️ Masukkan taruhan positif atau `all`. Contoh: `ltn slot 1.000`');
        if (uangData[userId] < taruhan) return message.reply('❌ Koin kamu tidak cukup.');
        if (!Number.isSafeInteger(taruhan * 5) || !Number.isSafeInteger(uangData[userId] - taruhan + taruhan * 5)) {
            return message.reply('⚠️ Taruhan terlalu besar untuk diproses dengan aman.');
        }
        const cooldown = mulaiCooldownGame(statePemain, 'slot', 10000);
        if (cooldown > 0) return message.reply(`⏳ Slot bisa dimainkan lagi <t:${Math.ceil((Date.now() + cooldown) / 1000)}:R>.`);

        uangData[userId] -= taruhan;
        const emojiSlot = ['🐺', '🐰', '🦊', '🐼', '🐉'];
        const acakSlot = () => Array.from({ length: 3 }, () => emojiSlot[Math.floor(Math.random() * emojiSlot.length)]);
        const hasilSlot = acakSlot();
        const pesanSlot = await message.reply(`🎰 **ANIMAL SLOT**\nTaruhan: **${formatUang(taruhan)} koin**\n[ ${acakSlot().join(' | ')} ]`);
        for (let putaran = 0; putaran < 7; putaran++) {
            await jeda(350 + putaran * 90);
            const gulungan = acakSlot();
            if (putaran >= 4) gulungan[0] = hasilSlot[0];
            if (putaran >= 5) gulungan[1] = hasilSlot[1];
            if (putaran >= 6) gulungan[2] = hasilSlot[2];
            await pesanSlot.edit(`🎰 **ANIMAL SLOT**\nTaruhan: **${formatUang(taruhan)} koin**\n[ ${gulungan.join(' | ')} ]`);
        }

        const sama = hasilSlot.filter(hewan => hewan === hasilSlot[0]).length;
        let hadiah = 0;
        if (sama === 3) hadiah = taruhan * 5;
        else if (sama === 2 || new Set(hasilSlot).size === 2) hadiah = Math.floor(taruhan * 1.5);
        uangData[userId] += hadiah;
        statePemain.stats.games = (statePemain.stats.games || 0) + 1;
        simpanRiwayat(statePemain, 'slot', hadiah - taruhan, hasilSlot.join(' '));
        simpanUang();
        simpanOwoState();
        const hasil = hadiah
            ? `🎉 Kamu menang **${formatUang(hadiah)} koin**!`
            : `💀 Zonk! Taruhan **${formatUang(taruhan)} koin** hilang.`;
        return pesanSlot.edit({
            content: `🎰 **ANIMAL SLOT**\n[ ${hasilSlot.join(' | ')} ]\n${hasil}\nSaldo: **${formatUang(uangData[userId])} koin**.`,
            components: tombolMainLagi(userId, 'slot', taruhan)
        });
    }

    if (command === 'mines') {
        const taruhan = parseJumlah(args[0], uangData[userId]);
        const jumlahBom = args[1] === undefined ? 3 : Number(args[1]);
        if (!taruhan) return message.reply('⚠️ Masukkan taruhan positif atau `all`. Contoh: `ltn mines 1.000 3`');
        if (!Number.isInteger(jumlahBom) || jumlahBom < 1 || jumlahBom > 8) {
            return message.reply('⚠️ Jumlah bom harus angka 1–8. Contoh: `ltn mines 1.000 3`.');
        }
        if (uangData[userId] < taruhan) return message.reply('❌ Koin kamu tidak cukup.');
        const cooldown = mulaiCooldownGame(statePemain, 'mines', 10000);
        if (cooldown > 0) return message.reply(`⏳ Mines bisa dimainkan lagi <t:${Math.ceil((Date.now() + cooldown) / 1000)}:R>.`);

        uangData[userId] -= taruhan;
        statePemain.stats.games = (statePemain.stats.games || 0) + 1;
        simpanRiwayat(statePemain, 'mines mulai', -taruhan, `${jumlahBom} bom`);
        simpanUang();
        simpanOwoState();
        const aman = new Set();
        const pilihan = new Map();
        const nomorRanjau = new Set();
        while (nomorRanjau.size < jumlahBom) {
            nomorRanjau.add(Math.floor(Math.random() * 9));
        }
        let selesai = false;
        let processing = false;
        const hitungCashOut = () => Math.floor(taruhan * pengaliMines(jumlahBom, aman.size));
        const buatTombol = () => {
            const baris = [];
            for (let awal = 0; awal < 9; awal += 3) {
                baris.push(new ActionRowBuilder().addComponents(
                    ...Array.from({ length: 3 }, (_, offset) => {
                        const nomor = awal + offset;
                        const status = pilihan.get(nomor);
                        const amanTerpilih = aman.has(nomor);
                        const bomTerungkap = selesai && nomorRanjau.has(nomor);
                        const tombol = new ButtonBuilder()
                            .setCustomId(`mines-cell-${nomor}`)
                            .setLabel(status === 'rolling' ? '🔄' : bomTerungkap ? '💣' : amanTerpilih ? '💎' : `${nomor + 1}`)
                            .setStyle(bomTerungkap ? ButtonStyle.Danger : amanTerpilih ? ButtonStyle.Success : ButtonStyle.Primary)
                            .setDisabled(selesai || processing || status === 'rolling' || status === 'mine' || amanTerpilih);
                        return tombol;
                    })
                ));
            }
            baris.push(new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId('mines-cashout').setLabel('Cash Out').setStyle(ButtonStyle.Secondary).setDisabled(selesai || processing)
            ));
            return baris;
        };
        const pesanGame = await message.reply({
            content: `💎 **MINES 3×3** — Taruhan **${formatUang(taruhan)} koin**\n💣 Bom: **${jumlahBom}** | 💎 Berlian aman: **0/${9 - jumlahBom}**\nCash out saat ini: **${formatUang(hitungCashOut())} koin** (x${pengaliMines(jumlahBom, aman.size).toFixed(2)})\nPilih kotak; setiap berlian menaikkan nilai cash out.`,
            components: buatTombol()
        });
        const collector = pesanGame.createMessageComponentCollector({
            time: 120000,
            filter: interaction => interaction.customId.startsWith('mines-')
        });

        collector.on('collect', async interaction => {
            if (interaction.user.id !== userId) {
                await interaction.reply({ content: 'Permainan ini bukan milikmu.', ephemeral: true });
                return;
            }
            if (selesai || processing) {
                await interaction.reply({ content: selesai ? 'Permainan ini sudah selesai.' : 'Tunggu animasi pilihan sebelumnya selesai.', ephemeral: true });
                return;
            }
            if (interaction.customId === 'mines-cashout') {
                const hadiah = hitungCashOut();
                uangData[userId] += hadiah;
                simpanRiwayat(statePemain, 'mines cash out', hadiah - taruhan, `${aman.size} berlian, ${jumlahBom} bom`);
                simpanUang();
                simpanOwoState();
                selesai = true;
                collector.stop('selesai');
                await interaction.update({
                    content: `💰 **CASH OUT BERHASIL**\nKamu mengamankan **${aman.size} berlian** dengan **${jumlahBom} bom** dan menerima **${formatUang(hadiah)} koin**.\nSaldo: **${formatUang(uangData[userId])} koin**.`,
                    components: []
                });
                return;
            }

            const nomor = Number(interaction.customId.slice('mines-cell-'.length));
            if (!Number.isInteger(nomor) || nomor < 0 || nomor > 8 || aman.has(nomor)) {
                await interaction.reply({ content: 'Kotak itu tidak valid atau sudah dipilih.', ephemeral: true });
                return;
            }

            processing = true;
            collector.resetTimer();
            pilihan.set(nomor, 'rolling');
            await interaction.update({
                content: `💎 **MINES 3×3** — Bom: **${jumlahBom}** | Berlian: **${aman.size}/${9 - jumlahBom}**\n🔎 Memeriksa kotak **${nomor + 1}**...`,
                components: buatTombol()
            });
            await jeda(700);

            if (nomorRanjau.has(nomor)) {
                pilihan.set(nomor, 'mine');
                selesai = true;
                simpanUang();
                simpanRiwayat(statePemain, 'mines kalah', -taruhan, `${aman.size} berlian, ${jumlahBom} bom`);
                simpanOwoState();
                collector.stop('selesai');
                await interaction.editReply({
                    content: `💥 **TERKENA BOM!** Kotak ${nomor + 1} berisi bom.\nKamu menemukan **${aman.size} berlian** sebelum kalah. Taruhan **${formatUang(taruhan)} koin** hilang.`,
                    components: buatTombol()
                });
                return;
            }

            aman.add(nomor);
            pilihan.set(nomor, 'diamond');
            if (aman.size === 9 - jumlahBom) {
                const hadiah = hitungCashOut();
                uangData[userId] += hadiah;
                simpanRiwayat(statePemain, 'mines jackpot', hadiah - taruhan, `${aman.size} berlian, ${jumlahBom} bom`);
                simpanUang();
                simpanOwoState();
                selesai = true;
                collector.stop('selesai');
                await interaction.editReply({
                    content: `🏆 **SEMUA BERLIAN DITEMUKAN!** Dengan **${jumlahBom} bom**, kamu menerima **${formatUang(hadiah)} koin**.\nSaldo: **${formatUang(uangData[userId])} koin**.`,
                    components: buatTombol()
                });
                return;
            }

            processing = false;
            await interaction.editReply({
                content: `💎 **BERLIAN DITEMUKAN!** Kotak ${nomor + 1} aman.\nBom: **${jumlahBom}** | Berlian: **${aman.size}/${9 - jumlahBom}**\nCash out sekarang: **${formatUang(hitungCashOut())} koin** (x${pengaliMines(jumlahBom, aman.size).toFixed(2)}).`,
                components: buatTombol()
            });
        });

        collector.on('end', async (_, alasan) => {
            if (alasan !== 'time' || selesai) return;
            const hadiah = hitungCashOut();
            uangData[userId] += hadiah;
            simpanRiwayat(statePemain, 'mines cash out otomatis', hadiah - taruhan, `${aman.size} berlian, ${jumlahBom} bom`);
            simpanUang();
            simpanOwoState();
            selesai = true;
            try {
                await pesanGame.edit({
                    content: `⏳ Waktu habis. Cash out otomatis untuk **${aman.size} berlian** dari **${jumlahBom} bom**: **${formatUang(hadiah)} koin**. Saldo: **${formatUang(uangData[userId])} koin**.`,
                    components: []
                });
            } catch (error) {
                console.error('Gagal memperbarui pesan mines setelah timeout:', error);
            }
        });
        return;
    }

    if (command === 'gamble') {
        const taruhan = parseJumlah(args[0], uangData[userId]);
        if (!taruhan) return message.reply('⚠️ Masukkan taruhan positif atau `all`. Contoh: `ltn gamble 1.000`');
        if (uangData[userId] < taruhan) return message.reply('❌ Koin kamu tidak cukup.');
        if (!Number.isSafeInteger(uangData[userId] + taruhan)) {
            return message.reply('⚠️ Saldo terlalu besar untuk memproses taruhan dengan aman.');
        }
        const cooldown = mulaiCooldownGame(statePemain, 'gamble', 10000);
        if (cooldown > 0) return message.reply(`⏳ Gamble bisa dimainkan lagi <t:${Math.ceil((Date.now() + cooldown) / 1000)}:R>.`);
        uangData[userId] -= taruhan;
        simpanUang();
        let taruhanDiselesaikan = false;
        try {
            const pesanDadu = await message.reply(`🎲 **ADU ANGKA**\nTaruhan dicadangkan: **${formatUang(taruhan)} koin**\nMengocok dadu...`);
            let angkaPemain = 0;
            let angkaBot = 0;
            for (let putaran = 0; putaran < 5; putaran++) {
                angkaPemain = Math.floor(Math.random() * 101);
                angkaBot = Math.floor(Math.random() * 101);
                await jeda(350);
                await pesanDadu.edit(`🎲 **ADU ANGKA**\nTaruhan: **${formatUang(taruhan)} koin**\nKamu: **${angkaPemain}** | Lawan: **${angkaBot}**`);
            }
            const menang = angkaPemain > angkaBot;
            const seri = angkaPemain === angkaBot;
            if (menang) uangData[userId] += taruhan;
            else if (seri) uangData[userId] += taruhan;
            const perubahanSaldo = seri ? 0 : menang ? taruhan : -taruhan;
            statePemain.stats.games = (statePemain.stats.games || 0) + 1;
            simpanRiwayat(statePemain, 'gamble', perubahanSaldo, `${angkaPemain} vs ${angkaBot}`);
            simpanUang();
            simpanOwoState();
            taruhanDiselesaikan = true;
            const hasil = seri
                ? '🤝 Seri! Taruhan dikembalikan.'
                : menang
                    ? `🎉 Kamu menang **${formatUang(taruhan)} koin**!`
                    : `💀 Kamu kalah **${formatUang(taruhan)} koin**.`;
            return await pesanDadu.edit({
                content: `🎲 **HASIL ADU ANGKA**\nKamu: **${angkaPemain}** | Lawan: **${angkaBot}**\n${hasil}\nSaldo: **${formatUang(uangData[userId])} koin**.`,
                components: tombolMainLagi(userId, 'gamble', taruhan)
            });
        } catch (error) {
            if (!taruhanDiselesaikan) {
                uangData[userId] += taruhan;
                simpanUang();
            }
            console.error('Gagal memproses gamble:', error);
            return message.reply(taruhanDiselesaikan
                ? '⚠️ Hasil gamble sudah diproses dan saldo tersimpan, tetapi pesan hasil gagal diperbarui.'
                : '⚠️ Gamble gagal diproses; taruhan sudah dikembalikan.')
                .catch(replyError => console.error('Gagal memberi tahu pemain tentang gamble:', replyError));
        }
    }

    // ==========================================
    // FITUR MENU HELP (BANTUAN)
    // ==========================================
    if (command === 'help' || command === 'bantuan') {
        if (args[0]?.toLowerCase() === 'admin') {
            if (!message.guild || !message.member.permissions.has(PermissionsBitField.Flags.ManageGuild)) {
                return message.reply('❌ Bantuan admin hanya tersedia bagi admin server dengan izin **Manage Server**.');
            }
            try {
                await message.author.send({
                    embeds: [buatHelpEmbed('moderasi', true)],
                    components: buatMenuHelp(message.author.id, 'moderasi', true, guildId)
                });
            } catch (error) {
                console.error('Gagal mengirim bantuan admin melalui DM:', error);
                return message.reply('❌ Saya tidak dapat mengirim DM. Aktifkan DM dari anggota server lalu coba `ltn help admin` lagi.');
            }
            return message.reply('🔐 Panduan khusus admin sudah dikirim ke DM agar daftar command tidak terlihat publik.');
        }
        return message.reply({
            embeds: [buatHelpEmbed('ringkasan', false)],
            components: buatMenuHelp(message.author.id, 'ringkasan', false)
        });
    }
});

client.on('interactionCreate', async interaction => {
    if (!interaction.isButton() && !interaction.isModalSubmit() && !interaction.isStringSelectMenu() && !interaction.isUserSelectMenu()) return;
    const guild = interaction.guild;
    const customId = interaction.customId;
    if (interaction.isButton() && customId.startsWith('replay:')) {
        const [, game, ownerId, rawBet, pilihan = 'none'] = customId.split(':');
        if (!guild || interaction.user.id !== ownerId) {
            await interaction.reply({ content: 'Tombol permainan ini hanya dapat digunakan oleh pemain yang memulai permainan.', ephemeral: true });
            return;
        }
        if (game === 'mines') {
            const taruhan = Number(rawBet);
            await jalankanGameUI(interaction, { game, userId: ownerId, taruhan, jumlahBom: Number(pilihan) });
            return;
        }
        const server = ambilDataServer(guild.id);
        const pemain = ambilDataPemain(server, ownerId, guild.id);
        if (game === 'hunt') {
            const hasil = berburu(server, pemain, guild.id, ownerId);
            if (!hasil.ok) {
                await interaction.reply({ content: `⏳ Kamu bisa berburu lagi <t:${Math.ceil((Date.now() + hasil.sisaCooldown) / 1000)}:R>.`, ephemeral: true });
                return;
            }
            await interaction.update({
                content: `🏹 Kamu berburu dan mendapatkan **${hasil.hewan.nama}**! Kelangkaan: **${hasil.hewan.kelangkaan}**.${hasil.pakaiUmpan ? ' 🪤 Umpan hoki digunakan.' : ''} Nilai jual: **${formatUang(hasil.hewan.nilai)} koin**.`,
                components: tombolMainLagi(ownerId, 'hunt', 0)
            });
            return;
        }
        if (!['cf', 'slot', 'gamble'].includes(game)) {
            await interaction.reply({ content: 'Jenis permainan tidak dikenal.', ephemeral: true });
            return;
        }
        const taruhan = Number(rawBet);
        const tebakan = pilihan;
        const cooldownMs = 10000;
        const uangData = economyData.servers[guild.id];
        if (!Number.isSafeInteger(taruhan) || taruhan < 1 ||
            (game === 'cf' && !['head', 'tail'].includes(tebakan))) {
            await interaction.reply({ content: 'Data taruhan tidak valid. Mulai permainan kembali dari command.', ephemeral: true });
            return;
        }
        if (uangData[ownerId] < taruhan) {
            await interaction.reply({ content: '❌ Saldo koin kamu tidak cukup untuk mengulang taruhan ini.', ephemeral: true });
            return;
        }
        if ((game === 'slot' && (!Number.isSafeInteger(taruhan * 5) || !Number.isSafeInteger(uangData[ownerId] - taruhan + taruhan * 5))) ||
            (game !== 'slot' && !Number.isSafeInteger(uangData[ownerId] + taruhan))) {
            await interaction.reply({ content: '⚠️ Taruhan terlalu besar untuk diproses dengan aman.', ephemeral: true });
            return;
        }
        const sisaCooldown = mulaiCooldownGame(pemain, game, cooldownMs);
        if (sisaCooldown > 0) {
            await interaction.reply({ content: `⏳ Kamu bisa bermain lagi <t:${Math.ceil((Date.now() + sisaCooldown) / 1000)}:R>.`, ephemeral: true });
            return;
        }

        uangData[ownerId] -= taruhan;
        simpanUang();
        let sudahSettlement = false;
        try {
            await interaction.update({
                content: game === 'cf'
                    ? `🪙 **COINFLIP** — taruhan **${formatUang(taruhan)} koin** dicadangkan.\nKoin dilempar...`
                    : game === 'slot'
                        ? `🎰 **ANIMAL SLOT** — taruhan **${formatUang(taruhan)} koin**\n[ ⚪ | 🟡 | ⚪ ]`
                        : `🎲 **ADU ANGKA** — taruhan **${formatUang(taruhan)} koin**\nMengocok dadu...`,
                embeds: [],
                components: []
            });

            let perubahanSaldo = 0;
            let hasilDetail = '';
            let narasi = '';
            if (game === 'cf') {
                for (const bingkai of ['⚪', '🟡', '⚪']) {
                    await jeda(400);
                    await interaction.editReply({ content: `🪙 **COINFLIP** — taruhan **${formatUang(taruhan)} koin**\n${bingkai} Koin berputar...` });
                }
                const hasil = Math.random() < 0.5 ? 'head' : 'tail';
                perubahanSaldo = hasil === tebakan ? taruhan : -taruhan;
                if (perubahanSaldo > 0) uangData[ownerId] += taruhan;
                hasilDetail = hasil;
                narasi = hasil === tebakan ? `🎉 Kamu menang **${formatUang(taruhan)} koin**!` : `💀 Kamu kalah **${formatUang(taruhan)} koin**.`;
            } else if (game === 'slot') {
                const simbol = ['🐺', '🐰', '🦊', '🐼', '🐉'];
                const acak = () => Array.from({ length: 3 }, () => simbol[Math.floor(Math.random() * simbol.length)]);
                const hasil = acak();
                for (let putaran = 0; putaran < 5; putaran++) {
                    await jeda(450);
                    const gulungan = acak();
                    if (putaran >= 2) gulungan[0] = hasil[0];
                    if (putaran >= 3) gulungan[1] = hasil[1];
                    if (putaran >= 4) gulungan[2] = hasil[2];
                    await interaction.editReply({ content: `🎰 **ANIMAL SLOT** — taruhan **${formatUang(taruhan)} koin**\n[ ${gulungan.join(' | ')} ]` });
                }
                const sama = hasil.filter(item => item === hasil[0]).length;
                const hadiah = sama === 3 ? taruhan * 5 : sama === 2 || new Set(hasil).size === 2 ? Math.floor(taruhan * 1.5) : 0;
                perubahanSaldo = hadiah - taruhan;
                uangData[ownerId] += hadiah;
                hasilDetail = hasil.join(' ');
                narasi = hadiah > taruhan
                    ? `🎉 Jackpot! Hadiah **${formatUang(hadiah)} koin**.`
                    : hadiah > 0
                        ? `✨ Menang **${formatUang(hadiah)} koin**.`
                        : `💀 Zonk! Taruhan **${formatUang(taruhan)} koin** hilang.`;
            } else {
                let angkaPemain = 0;
                let angkaBot = 0;
                for (let putaran = 0; putaran < 5; putaran++) {
                    angkaPemain = Math.floor(Math.random() * 101);
                    angkaBot = Math.floor(Math.random() * 101);
                    await jeda(350);
                    await interaction.editReply({ content: `🎲 **ADU ANGKA** — taruhan **${formatUang(taruhan)} koin**\nKamu: **${angkaPemain}** | Lawan: **${angkaBot}**` });
                }
                const menang = angkaPemain > angkaBot;
                const seri = angkaPemain === angkaBot;
                perubahanSaldo = seri ? 0 : menang ? taruhan : -taruhan;
                if (menang) uangData[ownerId] += taruhan;
                else if (seri) uangData[ownerId] += taruhan;
                hasilDetail = `${angkaPemain} vs ${angkaBot}`;
                narasi = seri ? '🤝 Seri! Taruhan dikembalikan.' : menang ? `🎉 Kamu menang **${formatUang(taruhan)} koin**!` : `💀 Kamu kalah **${formatUang(taruhan)} koin**.`;
            }

            pemain.stats.games = (pemain.stats.games || 0) + 1;
            simpanRiwayat(pemain, game === 'cf' ? 'coinflip' : game, perubahanSaldo, hasilDetail);
            simpanUang();
            simpanOwoState();
            sudahSettlement = true;
            const hasilPesan = game === 'cf'
                ? `🪙 **COINFLIP**\nHasil: **${hasilDetail.toUpperCase()}**\n${narasi}`
                : game === 'slot'
                    ? `🎰 **ANIMAL SLOT**\n[ ${hasilDetail} ]\n${narasi}`
                    : `🎲 **HASIL ADU ANGKA**\n${hasilDetail}\n${narasi}`;
            await interaction.editReply({
                content: `${hasilPesan}\nSaldo: **${formatUang(uangData[ownerId])} koin**.`,
                components: tombolMainLagi(ownerId, game, taruhan, tebakan)
            });
        } catch (error) {
            if (!sudahSettlement) {
                uangData[ownerId] += taruhan;
                pemain.gameCooldowns[game] = 0;
                simpanUang();
                simpanOwoState();
            }
            console.error(`Gagal menjalankan replay ${game}:`, error);
            if (interaction.deferred || interaction.replied) {
                await interaction.editReply({
                    content: sudahSettlement
                        ? 'Hasil sudah disimpan, tetapi pesan gagal diperbarui.'
                        : 'Permainan gagal diproses; taruhan telah dikembalikan.',
                    components: []
                }).catch(replyError => console.error('Gagal mengirim status replay:', replyError));
            } else {
                await interaction.reply({ content: 'Permainan gagal diproses.', ephemeral: true }).catch(replyError => console.error('Gagal memberi tahu pemain:', replyError));
            }
        }
        return;
    }

    if (interaction.isButton() && customId.startsWith('dashboard-open:')) {
        const [, ownerId, guildId] = customId.split(':');
        if (!guild || guildId !== guild.id || interaction.user.id !== ownerId) {
            await interaction.reply({ content: 'Dashboard ini hanya dapat dibuka oleh pemiliknya di server asal.', ephemeral: true });
            return;
        }
        try {
            const member = await guild.members.fetch(ownerId);
            await interaction.reply({
                embeds: [buatDashboardEmbed(guild.id, member)],
                components: buatKontrolDashboard(ownerId),
                ephemeral: true
            });
        } catch (error) {
            console.error('Gagal membuka dashboard pengguna:', error);
            await interaction.reply({ content: '❌ Dashboard gagal dibuka. Coba lagi sebentar.', ephemeral: true });
        }
        return;
    }

    if (interaction.isStringSelectMenu() && customId.startsWith('dashboard-page:')) {
        const [, ownerId] = customId.split(':');
        if (!guild || interaction.user.id !== ownerId) {
            await interaction.reply({ content: 'Dashboard ini hanya dapat digunakan oleh pemiliknya.', ephemeral: true });
            return;
        }
        const member = await guild.members.fetch(ownerId).catch(error => {
            console.error('Gagal mengambil anggota untuk dashboard:', error);
            return null;
        });
        if (!member) {
            await interaction.reply({ content: 'Anggota tidak ditemukan di server ini.', ephemeral: true });
            return;
        }
        const server = ambilDataServer(guild.id);
        const pemain = ambilDataPemain(server, ownerId, guild.id);
        const page = interaction.values[0];
        let embed;
        if (page === 'zoo') embed = buatZooEmbed(member, pemain);
        else if (page === 'inventory') {
            const daftar = Object.entries(pemain.inventory).filter(([, jumlah]) => Number.isSafeInteger(jumlah) && jumlah > 0);
            embed = new EmbedBuilder()
                .setColor(THEME_COLOR)
                .setAuthor({ name: `INVENTORY  •  ${member.displayName}`, iconURL: member.user.displayAvatarURL({ size: 128 }) })
                .setTitle('🎒 Perlengkapan')
                .setDescription(daftar.length
                    ? daftar.map(([id, jumlah]) => `• **${ITEM_TOKO[id]?.nama || id}** ×${formatUang(jumlah)}`).join('\n')
                    : 'Tasmu masih kosong.\n\nBuka menu **Aksi lainnya → Buka toko** untuk melihat perlengkapan yang tersedia.')
                .setFooter({ text: `${daftar.length} jenis item • gunakan menu Aksi lainnya untuk membuka toko` })
                .setTimestamp();
        } else if (page === 'history') {
            const riwayat = pemain.history.slice(-10).reverse();
            embed = new EmbedBuilder()
                .setColor(THEME_COLOR)
                .setAuthor({ name: `AKTIVITAS  •  ${member.displayName}`, iconURL: member.user.displayAvatarURL({ size: 128 }) })
                .setTitle('📜 Riwayat Terbaru')
                .setDescription(riwayat.length
                    ? riwayat.map(item => {
                        const nominal = item.amount === null
                            ? ''
                            : ` — ${item.amount > 0 ? '+' : item.amount < 0 ? '−' : ''}${formatUang(Math.abs(item.amount))} koin`;
                        return `• <t:${Math.floor(item.at / 1000)}:R> **${item.type}**${nominal}${item.detail ? ` (${item.detail})` : ''}`;
                    }).join('\n')
                    : 'Belum ada aktivitas yang tercatat.\n\nMulai klaim daily, berburu, atau bermain untuk mengisi riwayatmu.')
                .setFooter({ text: 'Menampilkan hingga 10 aktivitas terbaru' })
                .setTimestamp();
        } else if (page === 'games') {
            embed = new EmbedBuilder()
                .setColor(THEME_COLOR)
                .setAuthor({ name: `ARCADE  •  ${member.displayName}`, iconURL: member.user.displayAvatarURL({ size: 128 }) })
                .setTitle('🎮 Ruang Permainan')
                .setDescription(`Saldo tersedia: **${formatUang(economyData.servers[guild.id][ownerId])} koin**\nPilih game di menu **Pilih permainan** di bawah. Setiap ronde dimainkan privat dan taruhan dikunci sebelum dimulai.`)
                .addFields(
                    { name: '🪙 Coinflip', value: 'Tebak sisi koin dan gandakan taruhan jika tepat.', inline: true },
                    { name: '🎰 Animal Slot', value: 'Cocokkan simbol untuk memenangkan hadiah.', inline: true },
                    { name: '🎲 Adu Angka', value: 'Dapatkan angka lebih tinggi dari lawan.', inline: true },
                    { name: '💎 Mines', value: 'Atur jumlah bom, cari berlian, lalu cash out sebelum terkena bom.', inline: true }
                )
                .setFooter({ text: 'Cooldown tiap game: 10 detik • Main dengan bijak' })
                .setTimestamp();
        } else embed = buatDashboardEmbed(guild.id, member);
        await interaction.update({
            embeds: [embed],
            components: page === 'games'
                ? [...buatKontrolDashboard(ownerId, page), buatMenuGame(ownerId)]
                : buatKontrolDashboard(ownerId, page)
        });
        return;
    }

    if (interaction.isStringSelectMenu() && customId.startsWith('dashboard-game:')) {
        const [, ownerId] = customId.split(':');
        if (interaction.user.id !== ownerId || !guild) {
            await interaction.reply({ content: 'Menu game ini hanya dapat digunakan oleh pemilik dashboard.', ephemeral: true });
            return;
        }
        const modal = buatModalTaruhan(ownerId, guild.id, interaction.values[0]);
        if (!modal) {
            await interaction.reply({ content: 'Permainan tidak dikenal.', ephemeral: true });
            return;
        }
        await interaction.showModal(modal);
        return;
    }

    if (interaction.isModalSubmit() && customId.startsWith('dashboard-game-modal:')) {
        const [, guildId, ownerId, game] = customId.split(':');
        if (!guild || guild.id !== guildId || interaction.user.id !== ownerId) {
            await interaction.reply({ content: 'Form game ini tidak berlaku untuk pengguna/server ini.', ephemeral: true });
            return;
        }
        if (!['cf', 'slot', 'gamble', 'mines'].includes(game)) {
            await interaction.reply({ content: 'Jenis permainan tidak dikenal.', ephemeral: true });
            return;
        }
        ambilDataPemain(ambilDataServer(guildId), ownerId, guildId);
        const saldo = economyData.servers[guild.id][ownerId];
        const taruhan = parseJumlah(interaction.fields.getTextInputValue('bet').trim(), saldo);
        if (!taruhan) {
            await interaction.reply({ content: 'Masukkan taruhan positif yang valid atau `all`.', ephemeral: true });
            return;
        }
        const pilihan = game === 'cf' ? interaction.fields.getTextInputValue('side').trim().toLowerCase() : 'none';
        const jumlahBom = game === 'mines' ? Number(interaction.fields.getTextInputValue('bombs').trim()) : 3;
        await jalankanGameUI(interaction, { game, userId: ownerId, taruhan, pilihan, jumlahBom });
        return;
    }

    if (interaction.isUserSelectMenu() && customId.startsWith('dashboard-transfer-target:')) {
        const [, guildId, ownerId] = customId.split(':');
        if (!guild || guild.id !== guildId || interaction.user.id !== ownerId || interaction.values.length !== 1) {
            await interaction.reply({ content: 'Pemilih penerima ini tidak berlaku untuk pengguna/server ini.', ephemeral: true });
            return;
        }
        const targetId = interaction.values[0];
        const target = await guild.members.fetch(targetId).catch(error => {
            console.error('Gagal mencari penerima transfer dari pemilih anggota:', error);
            return null;
        });
        if (!target || target.user.bot || target.id === ownerId) {
            await interaction.reply({ content: 'Pilih anggota lain yang bukan bot sebagai penerima transfer.', ephemeral: true });
            return;
        }
        await interaction.showModal(buatModalJumlahTransfer(guildId, ownerId, targetId));
        return;
    }

    if ((interaction.isButton() && customId.startsWith('dashboard:')) ||
        (interaction.isStringSelectMenu() && customId.startsWith('dashboard-action:'))) {
        const isQuickAction = customId.startsWith('dashboard-action:');
        const [, ownerId, buttonAction] = customId.split(':');
        const action = isQuickAction ? interaction.values[0] : buttonAction;
        if (isQuickAction && !['transfer', 'sell', 'shop', 'bait', 'refresh'].includes(action)) {
            await interaction.reply({ content: 'Aksi dashboard tidak dikenal.', ephemeral: true });
            return;
        }
        if (!guild || interaction.user.id !== ownerId) {
            await interaction.reply({ content: 'Kontrol dashboard ini hanya dapat digunakan pemiliknya.', ephemeral: true });
            return;
        }
        if (action === 'transfer') {
            await interaction.reply({
                content: 'Cari nama penerima pada kotak pemilih Discord, lalu pilih anggotanya. Setelah itu masukkan jumlah koin.',
                components: [new ActionRowBuilder().addComponents(
                    new UserSelectMenuBuilder()
                        .setCustomId(`dashboard-transfer-target:${guild.id}:${ownerId}`)
                        .setPlaceholder('Cari anggota yang menerima koin')
                        .setMinValues(1)
                        .setMaxValues(1)
                )],
                ephemeral: true
            });
            return;
        }
        if (action === 'sell') {
            const dataServer = ambilDataServer(guild.id);
            const dataPemain = ambilDataPemain(dataServer, ownerId, guild.id);
            const ringkasanJual = ringkasanZoo(dataPemain);
            if (!ringkasanJual.ok) {
                const status = ringkasanJual.reason === 'overflow'
                    ? 'Nilai zoo melewati batas aman; tidak ada hewan yang dijual.'
                    : 'Zoo kamu tidak memiliki hewan yang bisa dijual.';
                await interaction.update({
                    embeds: [new EmbedBuilder().setColor(ERROR_COLOR).setTitle('Penjualan tidak dapat dilanjutkan').setDescription(status)],
                    components: buatKontrolDashboard(ownerId)
                });
                return;
            }
            if (!Number.isSafeInteger(economyData.servers[guild.id][ownerId] + ringkasanJual.totalKoin)) {
                await interaction.update({
                    embeds: [new EmbedBuilder()
                        .setColor(ERROR_COLOR)
                        .setTitle('Penjualan tidak dapat dilanjutkan')
                        .setDescription('Saldo setelah penjualan melewati batas aman; tidak ada hewan yang dijual.')],
                    components: buatKontrolDashboard(ownerId)
                });
                return;
            }
            await interaction.update({
                embeds: [new EmbedBuilder()
                    .setColor(THEME_COLOR)
                    .setTitle('🪙 Konfirmasi Penjualan Zoo')
                    .setDescription('Tinjau hasil penjualan sebelum mengonfirmasi. Hewan yang dijual tidak dapat dikembalikan.')
                    .addFields(
                        { name: 'Hewan yang dijual', value: `**${formatUang(ringkasanJual.totalHewan)}**`, inline: true },
                        { name: 'Koin yang diterima', value: `**${formatUang(ringkasanJual.totalKoin)}**`, inline: true }
                    )
                    .setFooter({ text: 'Penjualan hanya diproses setelah kamu mengonfirmasi.' })],
                components: [new ActionRowBuilder().addComponents(
                    new ButtonBuilder().setCustomId(`dashboard-sell:${ownerId}:confirm`).setLabel('Konfirmasi penjualan').setEmoji('🪙').setStyle(ButtonStyle.Danger),
                    new ButtonBuilder().setCustomId(`dashboard:${ownerId}:refresh`).setLabel('Kembali ke dashboard').setStyle(ButtonStyle.Secondary)
                )]
            });
            return;
        }
        const server = ambilDataServer(guild.id);
        const pemain = ambilDataPemain(server, ownerId, guild.id);
        const uangData = economyData.servers[guild.id];
        const member = await guild.members.fetch(ownerId).catch(error => {
            console.error('Gagal mengambil anggota untuk aksi dashboard:', error);
            return null;
        });
        if (!member) {
            await interaction.reply({ content: 'Anggota tidak ditemukan di server ini.', ephemeral: true });
            return;
        }
        if (action === 'shop') {
            const item = ITEM_TOKO.umpan;
            await interaction.update({
                embeds: [new EmbedBuilder()
                    .setColor(THEME_COLOR)
                    .setTitle('🛒 Toko Koin')
                    .setDescription(`**${item.nama}** — ${formatUang(item.harga)} koin\n${item.deskripsi}\n\nSaldo kamu: **${formatUang(uangData[ownerId])} koin**.`)],
                components: [new ActionRowBuilder().addComponents(
                    new ButtonBuilder().setCustomId(`dashboard:${ownerId}:buy`).setLabel(`Beli Umpan • ${formatUang(item.harga)} koin`).setStyle(ButtonStyle.Success),
                    new ButtonBuilder().setCustomId(`dashboard:${ownerId}:refresh`).setLabel('Kembali').setStyle(ButtonStyle.Secondary)
                ), ...buatKontrolDashboard(ownerId).slice(0, 1)]
            });
            return;
        }
        if (action === 'buy') {
            const item = ITEM_TOKO.umpan;
            if (uangData[ownerId] < item.harga) {
                await interaction.update({
                    embeds: [buatDashboardEmbed(guild.id, member, `❌ Koin tidak cukup. Harga umpan ${formatUang(item.harga)} koin.`)],
                    components: buatKontrolDashboard(ownerId)
                });
                return;
            }
            uangData[ownerId] -= item.harga;
            pemain.inventory.umpan = (pemain.inventory.umpan || 0) + 1;
            simpanRiwayat(pemain, 'pembelian', -item.harga, item.nama);
            simpanUang();
            simpanOwoState();
            await interaction.update({
                embeds: [buatDashboardEmbed(guild.id, member, `✅ Membeli **${item.nama}** seharga **${formatUang(item.harga)} koin**.`)],
                components: buatKontrolDashboard(ownerId)
            });
            return;
        }
        if (action === 'bait') {
            if ((pemain.inventory.umpan || 0) < 1) {
                await interaction.update({
                    embeds: [buatDashboardEmbed(guild.id, member, 'Kamu belum memiliki umpan. Buka toko dari dashboard untuk membelinya.')],
                    components: buatKontrolDashboard(ownerId)
                });
                return;
            }
            if (pemain.huntBoost) {
                await interaction.update({
                    embeds: [buatDashboardEmbed(guild.id, member, '🪤 Umpan sudah dipasang untuk perburuan berikutnya.')],
                    components: buatKontrolDashboard(ownerId)
                });
                return;
            }
            pemain.inventory.umpan--;
            pemain.huntBoost = true;
            simpanOwoState();
            await interaction.update({
                embeds: [buatDashboardEmbed(guild.id, member, '🪤 Umpan hoki dipasang. Peluang hewan langka meningkat pada hunt berikutnya.')],
                components: buatKontrolDashboard(ownerId)
            });
            return;
        }
        if (action === 'daily') {
            const hasil = klaimDaily(server, pemain, uangData, ownerId);
            const status = hasil.ok
                ? `🎁 Daily berhasil diklaim! **${formatUang(hasil.hadiah)} koin** • streak **${hasil.streak} hari**.`
                : `⏳ Daily belum tersedia. Coba lagi <t:${Math.ceil((Date.now() + hasil.sisaCooldown) / 1000)}:R>.`;
            await interaction.update({
                embeds: [buatDashboardEmbed(guild.id, member, status)],
                components: buatKontrolDashboard(ownerId)
            });
            return;
        }
        if (action === 'hunt') {
            const hasil = berburu(server, pemain, guild.id, ownerId);
            const status = hasil.ok
                ? `🏹 Mendapat **${hasil.hewan.nama}** (${hasil.hewan.kelangkaan}), nilai jual ${formatUang(hasil.hewan.nilai)} koin.${hasil.pakaiUmpan ? ' Umpan digunakan.' : ''}`
                : `⏳ Berburu lagi <t:${Math.ceil((Date.now() + hasil.sisaCooldown) / 1000)}:R>.`;
            await interaction.update({
                embeds: [buatDashboardEmbed(guild.id, member, status)],
                components: buatKontrolDashboard(ownerId)
            });
            return;
        }
        if (action === 'zoo') {
            await interaction.update({ embeds: [buatZooEmbed(member, pemain)], components: buatKontrolDashboard(ownerId, 'zoo') });
            return;
        }
        if (action === 'refresh') {
            await interaction.update({ embeds: [buatDashboardEmbed(guild.id, member)], components: buatKontrolDashboard(ownerId) });
            return;
        }
    }

    if (interaction.isButton() && customId.startsWith('dashboard-sell:')) {
        const [, ownerId, aksi] = customId.split(':');
        if (!guild || interaction.user.id !== ownerId || aksi !== 'confirm') {
            await interaction.reply({ content: 'Aksi ini hanya dapat digunakan pemilik dashboard.', ephemeral: true });
            return;
        }
        const server = ambilDataServer(guild.id);
        const pemain = ambilDataPemain(server, ownerId, guild.id);
        const member = await guild.members.fetch(ownerId).catch(error => {
            console.error('Gagal mengambil anggota untuk penjualan zoo:', error);
            return null;
        });
        if (!member) {
            await interaction.reply({ content: 'Anggota tidak ditemukan di server ini.', ephemeral: true });
            return;
        }
        const hasil = jualZoo(pemain, economyData.servers[guild.id], ownerId);
        const status = hasil.ok
            ? `💰 Terjual **${formatUang(hasil.hewanTerjual)} hewan** seharga **${formatUang(hasil.hasilJual)} koin**.`
            : hasil.reason === 'saldo_limit'
                ? '⚠️ Saldo setelah penjualan melewati batas aman; tidak ada hewan yang dijual.'
                : hasil.reason === 'overflow'
                    ? '⚠️ Nilai zoo melewati batas aman; tidak ada hewan yang dijual.'
                    : 'Zoo kamu tidak memiliki hewan yang bisa dijual.';
        await interaction.update({
            embeds: [buatDashboardEmbed(guild.id, member, status)],
            components: buatKontrolDashboard(ownerId)
        });
        return;
    }

    if (interaction.isModalSubmit() && (customId.startsWith('dashboard-transfer:') || customId.startsWith('dashboard-transfer-modal:'))) {
        const isPickerFlow = customId.startsWith('dashboard-transfer-modal:');
        const [, guildId, ownerId, selectedTargetId] = customId.split(':');
        if (!guild || guild.id !== guildId || interaction.user.id !== ownerId) {
            await interaction.reply({ content: 'Form transfer ini tidak berlaku untuk pengguna/server ini.', ephemeral: true });
            return;
        }
        const targetId = isPickerFlow
            ? selectedTargetId
            : (() => {
                const targetText = interaction.fields.getTextInputValue('target').trim();
                return targetText.match(/^<@!?(\d{17,20})>$/)?.[1] || (/^\d{17,20}$/.test(targetText) ? targetText : null);
            })();
        const server = ambilDataServer(guild.id);
        const saldo = economyData.servers[guild.id][ownerId];
        const jumlah = parseJumlah(interaction.fields.getTextInputValue('amount').trim(), saldo);
        if (!targetId || targetId === ownerId || !jumlah) {
            await interaction.reply({ content: 'Penerima atau jumlah tidak valid. Jumlah harus positif, memakai format titik ribuan, atau `all`.', ephemeral: true });
            return;
        }
        const target = await guild.members.fetch(targetId).catch(() => null);
        if (!target || target.user.bot || saldo < jumlah) {
            await interaction.reply({ content: 'Penerima tidak valid, merupakan bot, atau saldo koin tidak cukup.', ephemeral: true });
            return;
        }
        const saldoPenerima = economyData.servers[guild.id][targetId] ?? server.settings.startingBalance;
        if (!Number.isSafeInteger(saldoPenerima + jumlah)) {
            await interaction.reply({ content: 'Saldo penerima mencapai batas aman. Transfer dibatalkan.', ephemeral: true });
            return;
        }
        const token = `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 7)}`;
        transferDashboardPending.set(token, { guildId: guild.id, fromId: ownerId, toId: targetId, amount: jumlah });
        setTimeout(() => transferDashboardPending.delete(token), 120000);
        await interaction.reply({
            embeds: [new EmbedBuilder().setColor(THEME_COLOR).setTitle('Konfirmasi Transfer')
                .setDescription(`Kirim **${formatUang(jumlah)} koin** kepada ${target}?\nSaldo setelah transfer: **${formatUang(saldo - jumlah)} koin**.`)],
            components: [new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId(`dashboard-transfer-confirm:${ownerId}:${token}`).setLabel('Konfirmasi Transfer').setStyle(ButtonStyle.Success),
                new ButtonBuilder().setCustomId(`dashboard-transfer-cancel:${ownerId}:${token}`).setLabel('Batalkan').setStyle(ButtonStyle.Secondary)
            )],
            ephemeral: true
        });
        return;
    }

    if (interaction.isButton() && (customId.startsWith('dashboard-transfer-confirm:') || customId.startsWith('dashboard-transfer-cancel:'))) {
        const [prefix, ownerId, token] = customId.split(':');
        const pending = transferDashboardPending.get(token);
        if (interaction.user.id !== ownerId || !pending || pending.guildId !== guild?.id) {
            await interaction.reply({ content: 'Konfirmasi transfer tidak berlaku atau sudah kedaluwarsa.', ephemeral: true });
            return;
        }
        transferDashboardPending.delete(token);
        if (prefix === 'dashboard-transfer-cancel') {
            await interaction.update({ content: 'Transfer dibatalkan.', embeds: [], components: [] });
            return;
        }
        const uangData = economyData.servers[pending.guildId];
        if (uangData[pending.fromId] < pending.amount) {
            await interaction.update({ content: 'Saldo berubah dan tidak lagi cukup. Transfer tidak dilakukan.', embeds: [], components: [] });
            return;
        }
        const server = ambilDataServer(pending.guildId);
        const pemainPengirim = ambilDataPemain(server, pending.fromId, pending.guildId);
        const pemainPenerima = ambilDataPemain(server, pending.toId, pending.guildId);
        const target = await guild.members.fetch(pending.toId).catch(() => null);
        if (!target || target.user.bot) {
            await interaction.update({ content: 'Penerima tidak lagi tersedia di server. Transfer dibatalkan.', embeds: [], components: [] });
            return;
        }
        const saldoPenerima = uangData[pending.toId] ?? server.settings.startingBalance;
        if (!Number.isSafeInteger(saldoPenerima + pending.amount)) {
            await interaction.update({ content: 'Saldo penerima telah mencapai batas aman. Transfer dibatalkan.', embeds: [], components: [] });
            return;
        }
        uangData[pending.fromId] -= pending.amount;
        uangData[pending.toId] += pending.amount;
        simpanRiwayat(pemainPengirim, 'transfer keluar', -pending.amount, `ke ${target.user.tag}`);
        simpanRiwayat(pemainPenerima, 'transfer masuk', pending.amount, `dari ${interaction.user.tag}`);
        simpanUang();
        simpanOwoState();
        await interaction.update({ content: `✅ Berhasil mengirim **${formatUang(pending.amount)} koin** kepada **${target.user.tag}**.`, embeds: [], components: [] });
        return;
    }

    if (interaction.isStringSelectMenu() && customId.startsWith('help-select:')) {
        const [, mode, guildIdHelp, userIdHelp] = customId.split(':');
        const adminMode = mode === 'admin';
        const pemilikId = adminMode ? userIdHelp : mode === 'public' ? guildIdHelp : mode;
        const targetGuildId = adminMode ? guildIdHelp : null;
        if (interaction.user.id !== pemilikId) {
            await interaction.reply({
                content: 'Menu bantuan ini dibuka oleh orang lain. Jalankan `ltn help` untuk membuka menu milikmu.',
                ephemeral: true
            });
            return;
        }
        let guildHelp = interaction.guild;
        if (adminMode) {
            if (!targetGuildId) {
                await interaction.reply({ content: 'Menu admin tidak valid. Jalankan `ltn help admin` dari server.', ephemeral: true });
                return;
            }
            try {
                guildHelp = await client.guilds.fetch(targetGuildId);
                const member = await guildHelp.members.fetch(pemilikId);
                if (!member.permissions.has(PermissionsBitField.Flags.ManageGuild)) {
                    await interaction.reply({ content: 'Akses bantuan admin dicabut karena kamu tidak lagi memiliki izin Manage Server.', ephemeral: true });
                    return;
                }
            } catch (error) {
                console.error('Gagal memverifikasi akses menu bantuan admin:', error);
                await interaction.reply({ content: 'Akses bantuan admin tidak dapat diverifikasi. Jalankan kembali `ltn help admin` di server.', ephemeral: true });
                return;
            }
        }
        const kategori = interaction.values[0];
        const kategoriYangDiizinkan = adminMode ? kategoriHelpAdmin : kategoriHelpPublik;
        if (!kategoriYangDiizinkan[kategori]) {
            await interaction.reply({ content: 'Kategori bantuan tidak dikenal. Buka kembali dengan `ltn help`.', ephemeral: true });
            return;
        }
        await interaction.update({
            embeds: [buatHelpEmbed(kategori, adminMode)],
            components: buatMenuHelp(pemilikId, kategori, adminMode, targetGuildId)
        });
        return;
    }

    if (customId.startsWith('verify:') && interaction.isButton()) {
        if (!guild || customId !== `verify:${guild.id}`) {
            await interaction.reply({ content: 'Panel verifikasi ini tidak berlaku di server ini.', ephemeral: true });
            return;
        }
        const roleId = ambilDataServer(guild.id).settings.verifyRoleId;
        const role = roleId && guild.roles.cache.get(roleId);
        const member = await guild.members.fetch(interaction.user.id).catch(error => {
            console.error('Gagal mencari anggota untuk verifikasi:', error);
            return null;
        });
        if (!member || !role) {
            await interaction.reply({ content: 'Role verifikasi tidak tersedia. Hubungi admin server.', ephemeral: true });
            return;
        }
        if (member.roles.cache.has(role.id)) {
            await interaction.reply({ content: '✅ Kamu sudah terverifikasi.', ephemeral: true });
            return;
        }
        try {
            await member.roles.add(role, 'Verifikasi anggota melalui panel');
            await interaction.reply({ content: `✅ Berhasil diverifikasi dan mendapatkan role ${role}.`, ephemeral: true });
        } catch (error) {
            console.error('Gagal memberikan role verifikasi:', error);
            await interaction.reply({ content: '❌ Verifikasi gagal. Admin perlu memeriksa izin Manage Roles dan hierarki role bot.', ephemeral: true });
        }
        return;
    }

    if (customId.startsWith('report:') && interaction.isButton()) {
        if (!guild || customId !== `report:${guild.id}`) {
            await interaction.reply({ content: 'Panel laporan ini tidak berlaku di server ini.', ephemeral: true });
            return;
        }
        const modal = new ModalBuilder().setCustomId(`report-modal:${guild.id}`).setTitle('Kirim Laporan');
        const target = new TextInputBuilder().setCustomId('target').setLabel('Anggota yang dilaporkan (mention/ID)').setStyle(TextInputStyle.Short).setRequired(false).setMaxLength(30);
        const detail = new TextInputBuilder().setCustomId('detail').setLabel('Jelaskan laporan dan bukti').setStyle(TextInputStyle.Paragraph).setRequired(true).setMaxLength(1000);
        modal.addComponents(
            new ActionRowBuilder().addComponents(target),
            new ActionRowBuilder().addComponents(detail)
        );
        await interaction.showModal(modal);
        return;
    }

    if (customId.startsWith('admincfg:') && interaction.isButton()) {
        const [, action, targetGuildId] = customId.split(':');
        if (!guild || targetGuildId !== guild.id || !interaction.memberPermissions?.has(PermissionsBitField.Flags.ManageGuild)) {
            await interaction.reply({ content: '❌ Panel ini hanya dapat digunakan admin server yang memiliki izin Manage Server.', ephemeral: true });
            return;
        }
        const labels = {
            welcome: ['Atur Welcome', 'Mention channel teks atau off'],
            goodbye: ['Atur Goodbye', 'Mention channel teks atau off'],
            autorole: ['Atur Auto-role', 'Mention role atau off'],
            report: ['Atur Channel Laporan', 'Mention channel teks tujuan'],
            verify: ['Atur Role Verifikasi', 'Mention role untuk verifikasi'],
            modlog: ['Atur Log Moderasi', 'Mention channel teks atau off']
        }[action];
        if (!labels) {
            await interaction.reply({ content: 'Aksi panel admin tidak dikenali.', ephemeral: true });
            return;
        }
        const modal = new ModalBuilder().setCustomId(`admincfg-modal:${action}:${guild.id}`).setTitle(labels[0]);
        const input = new TextInputBuilder().setCustomId('value').setLabel(labels[1]).setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(100);
        modal.addComponents(new ActionRowBuilder().addComponents(input));
        await interaction.showModal(modal);
        return;
    }

    if (interaction.isModalSubmit() && customId.startsWith('report-modal:')) {
        if (!guild || customId !== `report-modal:${guild.id}`) {
            await interaction.reply({ content: 'Form laporan ini tidak berlaku di server ini.', ephemeral: true });
            return;
        }
        const server = ambilDataServer(guild.id);
        const channelId = server.settings.reportChannelId || modLogConfig[guild.id];
        const channel = channelId && await guild.channels.fetch(channelId).catch(error => {
            console.error('Gagal mencari channel laporan:', error);
            return null;
        });
        if (!channel?.isTextBased()) {
            await interaction.reply({ content: 'Channel laporan belum diatur. Hubungi admin server.', ephemeral: true });
            return;
        }
        const targetText = interaction.fields.getTextInputValue('target').trim();
        const targetId = targetText.match(/^<@!?(\d{17,20})>$/)?.[1] || (/^\d{17,20}$/.test(targetText) ? targetText : null);
        const detail = interaction.fields.getTextInputValue('detail').trim();
        try {
            await channel.send({
                embeds: [new EmbedBuilder().setColor(THEME_COLOR).setTitle('🚩 Laporan Anggota')
                    .addFields(
                        { name: 'Pelapor', value: `${interaction.user} (\`${interaction.user.tag}\`)` },
                        { name: 'Target', value: targetId ? `<@${targetId}> (\`${targetId}\`)` : (targetText || 'Tidak disebutkan') },
                        { name: 'Detail', value: detail.slice(0, 1000) }
                    ).setTimestamp()],
                allowedMentions: { parse: [] }
            });
            catatLogMod(guild.id, `🚩 Laporan baru dikirim oleh ${interaction.user.tag}. Target: ${targetId || 'tidak disebutkan'}.`);
            await interaction.reply({ content: '✅ Laporan berhasil dikirim secara rahasia kepada tim moderasi.', ephemeral: true });
        } catch (error) {
            console.error('Gagal meneruskan laporan anggota:', error);
            await interaction.reply({ content: '❌ Laporan gagal dikirim. Coba lagi atau hubungi admin.', ephemeral: true });
        }
        return;
    }

    if (interaction.isModalSubmit() && customId.startsWith('admincfg-modal:')) {
        const [, action, targetGuildId] = customId.split(':');
        if (!guild || targetGuildId !== guild.id || !interaction.memberPermissions?.has(PermissionsBitField.Flags.ManageGuild)) {
            await interaction.reply({ content: '❌ Hanya admin dengan izin Manage Server yang dapat mengubah pengaturan ini.', ephemeral: true });
            return;
        }
        const server = ambilDataServer(guild.id);
        const value = interaction.fields.getTextInputValue('value').trim();
        const channelId = value.match(/^<#(\d{17,20})>$/)?.[1];
        const roleId = value.match(/^<@&(\d{17,20})>$/)?.[1];
        if (action === 'welcome' || action === 'goodbye') {
            const key = `${action}ChannelId`;
            if (value.toLowerCase() === 'off') delete server.settings[key];
            else if (!channelId || !guild.channels.cache.get(channelId)?.isTextBased()) {
                await interaction.reply({ content: 'Masukkan mention channel teks yang valid atau `off`.', ephemeral: true });
                return;
            } else server.settings[key] = channelId;
            simpanOwoState();
            await interaction.reply({ content: `✅ Pengaturan ${action} berhasil diperbarui.`, ephemeral: true });
            return;
        }
        if (action === 'autorole' || action === 'verify') {
            const key = action === 'autorole' ? 'autoroleId' : 'verifyRoleId';
            if (value.toLowerCase() === 'off' && action === 'autorole') delete server.settings[key];
            else if (!roleId || !guild.roles.cache.has(roleId)) {
                await interaction.reply({ content: 'Masukkan mention role yang valid.', ephemeral: true });
                return;
            } else server.settings[key] = roleId;
            simpanOwoState();
            await interaction.reply({ content: `✅ Pengaturan role ${action} berhasil diperbarui.`, ephemeral: true });
            return;
        }
        if (action === 'report' || action === 'modlog') {
            if (action === 'modlog' && value.toLowerCase() === 'off') {
                delete modLogConfig[guild.id];
                fs.writeFileSync(PATH_MOD_LOG, JSON.stringify(modLogConfig, null, 2));
            } else if (!channelId || !guild.channels.cache.get(channelId)?.isTextBased()) {
                await interaction.reply({ content: 'Masukkan mention channel teks yang valid' + (action === 'modlog' ? ' atau `off`.' : '.'), ephemeral: true });
                return;
            } else if (action === 'report') server.settings.reportChannelId = channelId;
            else modLogConfig[guild.id] = channelId;
            simpanOwoState();
            if (action === 'modlog') fs.writeFileSync(PATH_MOD_LOG, JSON.stringify(modLogConfig, null, 2));
            await interaction.reply({ content: `✅ Pengaturan ${action} berhasil diperbarui.`, ephemeral: true });
            return;
        }
        await interaction.reply({ content: 'Aksi konfigurasi tidak dikenal.', ephemeral: true });
        return;
    }

    const sharedPanel = interaction.isButton() && interaction.customId.startsWith('tempvoice-shared:');
    const prefix = sharedPanel
        ? 'tempvoice-shared:'
        : interaction.isButton()
            ? 'tempvoice:'
            : interaction.isUserSelectMenu()
                ? 'tempvoice-user:'
                : 'tempvoice-modal:';
    if (!interaction.customId.startsWith(prefix)) return;

    let action;
    let roomId;
    let panelOwnerId;
    if (!guild) {
        await interaction.reply({ content: 'Panel hanya dapat digunakan di server.', ephemeral: true });
        return;
    }

    const server = ambilDataServer(guild.id);
    if (sharedPanel) {
        const [, sharedAction, targetGuildId] = interaction.customId.split(':');
        if (
            targetGuildId !== guild.id ||
            server.voice.panelChannelId !== interaction.channelId ||
            server.voice.panelMessageId !== interaction.message.id
        ) {
            await interaction.reply({ content: 'Panel voice bersama ini sudah tidak aktif. Minta admin mengirim panel terbaru.', ephemeral: true });
            return;
        }
        action = sharedAction;
        roomId = interaction.member?.voice?.channelId;
        if (!roomId) {
            await interaction.reply({ content: 'Masuk ke voice sementara milikmu terlebih dahulu untuk menggunakan panel bersama.', ephemeral: true });
            return;
        }
    } else {
        const parts = interaction.customId.split(':');
        [, action, roomId, panelOwnerId] = parts;
    }
    const ownerId = server.voice.rooms[roomId];
    const room = guild.channels.cache.get(roomId);
    if (!ownerId || !room || room.type !== ChannelType.GuildVoice) {
        await interaction.reply({ content: 'Voice sementara ini sudah tidak tersedia.', ephemeral: true });
        return;
    }

    const isOwner = interaction.user.id === ownerId;
    if (sharedPanel && !isOwner && action !== 'claim') {
        await interaction.reply({ content: `Panel ini hanya dapat digunakan pemilik voice (<@${ownerId}>).`, ephemeral: true });
        return;
    }
    if (action === 'claim') {
        const pemilikLama = room.members.get(ownerId);
        if (pemilikLama) {
            await interaction.reply({ content: 'Pemilik voice masih berada di channel. Minta pemilik memakai tombol Transfer.', ephemeral: true });
            return;
        }
        if (!room.members.has(interaction.user.id)) {
            await interaction.reply({ content: 'Untuk mengambil alih voice, kamu harus berada di dalam channel tersebut.', ephemeral: true });
            return;
        }
        try {
            await room.permissionOverwrites.edit(interaction.user.id, {
                ViewChannel: true,
                Connect: true,
                Speak: true
            });
            server.voice.rooms[roomId] = interaction.user.id;
            simpanOwoState();
            catatAksiPanelVoice(guild.id, room, interaction.user, 'mengklaim kepemilikan voice');
            await interaction.reply({ content: `👑 Kamu sekarang pemilik **${room.name}**.`, ephemeral: true });
        } catch (error) {
            console.error('Gagal mengklaim voice sementara:', error);
            await interaction.reply({ content: '❌ Gagal mengambil alih voice. Periksa izin bot.', ephemeral: true });
        }
        return;
    }

    if (!isOwner) {
        await interaction.reply({ content: `Panel ini hanya dapat digunakan pemilik voice (<@${ownerId}>).`, ephemeral: true });
        return;
    }

    if (interaction.isButton() && action === 'info') {
        const everyoneOverwrite = room.permissionOverwrites.cache.get(guild.roles.everyone.id);
        const embed = new EmbedBuilder()
            .setColor(THEME_COLOR)
            .setTitle('Voice Room Information')
            .setDescription(`Informasi untuk **${room.name}**.`)
            .addFields(
                { name: 'Owner', value: `<@${ownerId}>`, inline: true },
                { name: 'Members', value: `${room.members.size}`, inline: true },
                { name: 'User limit', value: room.userLimit ? `${room.userLimit}` : 'Unlimited', inline: true },
                {
                    name: 'Privacy',
                    value: everyoneOverwrite?.deny.has(PermissionsBitField.Flags.ViewChannel) ? 'Private' : 'Public',
                    inline: true
                }
            );
        await interaction.reply({ embeds: [embed], ephemeral: true });
        return;
    }

    if (interaction.isButton() && action === 'log') {
        const events = (adminLogs[guild.id] || [])
            .filter(item => item?.type === 'voice-panel' && typeof item.text === 'string' && item.text.includes(`(${room.id})`))
            .slice(-8)
            .reverse();
        const embed = new EmbedBuilder()
            .setColor(THEME_COLOR)
            .setTitle(`Voice Room Log • ${room.name}`)
            .setDescription(events.length
                ? events.map(item => `• <t:${Math.floor(item.at / 1000)}:t> ${amanUntukTeksDiscord(item.text.replace(/^🔊 \[VOICE PANEL\] /, '').replace(` (${room.id}).`, ''))}`).join('\n').slice(0, 4000)
                : 'Belum ada aktivitas panel yang tercatat untuk room ini.');
        await interaction.reply({ embeds: [embed], ephemeral: true });
        return;
    }

    if (interaction.isUserSelectMenu()) {
        const actionsAnggota = ['trust', 'untrust', 'invite', 'kick', 'block', 'unblock', 'transfer'];
        if (panelOwnerId !== ownerId || !actionsAnggota.includes(action) || interaction.values.length !== 1) {
            await interaction.reply({ content: 'Pilihan anggota tidak valid. Buka kembali panel voice dan coba lagi.', ephemeral: true });
            return;
        }
        try {
            await interaction.deferUpdate();
            await jalankanAksiAnggotaVoice(interaction, room, action, interaction.values[0], server, ownerId);
            await interaction.editReply({ content: 'Pilihan anggota sudah diproses.', components: [] });
        } catch (error) {
            console.error(`Gagal menjalankan aksi voice ${action} dari menu anggota:`, error);
            await interaction.followUp({ content: '❌ Aksi gagal diterapkan. Pastikan bot memiliki izin yang dibutuhkan.', ephemeral: true }).catch(replyError => {
                console.error('Gagal mengirim respons error menu anggota voice:', replyError);
            });
            await interaction.editReply({ content: 'Aksi gagal. Pilih anggota melalui panel untuk mencoba lagi.', components: [] }).catch(replyError => {
                console.error('Gagal menonaktifkan menu anggota voice:', replyError);
            });
        }
        return;
    }

    if (interaction.isButton() && ['name', 'limit', 'trust', 'untrust', 'invite', 'kick', 'block', 'unblock', 'transfer', 'delete', 'reset'].includes(action)) {
        if (['trust', 'untrust', 'invite', 'kick', 'block', 'unblock', 'transfer'].includes(action)) {
            const instruksi = action === 'transfer' || action === 'kick'
                ? 'Cari nama anggota, lalu pilih. Anggota harus sedang berada di voice channel ini.'
                : 'Cari nama anggota di kotak pencarian Discord, lalu pilih dari daftar.';
            await interaction.reply({
                content: `${instruksi}\nPilihan anggota hanya dapat digunakan oleh pemilik voice dan berlaku untuk **${room.name}**.`,
                components: [buatMenuPilihAnggotaVoice(action, roomId, ownerId)],
                ephemeral: true
            });
            return;
        }
        const modal = buatModalVoice(action, roomId);
        await interaction.showModal(modal);
        return;
    }

    if (interaction.isButton()) {
        try {
            const everyoneId = guild.roles.everyone.id;
            const everyoneOverwrite = room.permissionOverwrites.cache.get(everyoneId);

            if (action === 'privacy') {
                const isPrivate = everyoneOverwrite?.deny.has(PermissionsBitField.Flags.ViewChannel) || false;
                await room.permissionOverwrites.edit(everyoneId, {
                    ViewChannel: isPrivate ? null : false,
                    Connect: isPrivate ? null : false
                });
                await room.permissionOverwrites.edit(ownerId, {
                    ViewChannel: true,
                    Connect: true,
                    Speak: true
                });
                catatAksiPanelVoice(guild.id, room, interaction.user, isPrivate ? 'membuka privasi room' : 'mengaktifkan privasi room');
                await interaction.reply({ content: isPrivate ? '🔓 Room sekarang terlihat oleh semua anggota.' : '🔒 Room sekarang privat; hanya anggota yang diundang/trusted dapat melihatnya.', ephemeral: true });
                return;
            }

            if (action === 'delete') {
                await interaction.reply({ content: 'Gunakan form konfirmasi yang dibuka untuk menghapus voice.', ephemeral: true });
                return;
            }

            await interaction.reply({ content: 'Tombol tidak dikenali.', ephemeral: true });
        } catch (error) {
            console.error(`Gagal menjalankan tombol voice ${action}:`, error);
            await interaction.reply({ content: '❌ Pengaturan voice gagal diterapkan. Periksa izin **Manage Channels** bot.', ephemeral: true }).catch(replyError => {
                console.error('Gagal mengirim respons error panel voice:', replyError);
            });
        }
        return;
    }

    const nilai = interaction.fields.getTextInputValue('value').trim();
    try {
        if (action === 'delete') {
            if (nilai !== 'DELETE') {
                await interaction.reply({ content: 'Konfirmasi tidak cocok. Voice tidak dihapus.', ephemeral: true });
                return;
            }
            catatAksiPanelVoice(guild.id, room, interaction.user, 'menghapus voice sementara');
            await interaction.reply({ content: '🗑️ Menghapus voice sementara...', ephemeral: true });
            await room.delete(`Dihapus pemilik ${interaction.user.tag}`);
            return;
        }

        if (action === 'reset') {
            if (nilai !== 'RESET') {
                await interaction.reply({ content: 'Konfirmasi tidak cocok. Pengaturan voice tidak diubah.', ephemeral: true });
                return;
            }
            const pemilik = await guild.members.fetch(ownerId);
            await room.edit({
                name: `🔊 ${pemilik.displayName}`.slice(0, 100),
                userLimit: 0,
                permissionOverwrites: [
                    {
                        id: guild.roles.everyone.id,
                        allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.Connect]
                    },
                    {
                        id: ownerId,
                        allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.Connect, PermissionsBitField.Flags.Speak]
                    }
                ]
            }, `Reset pengaturan oleh ${interaction.user.tag}`);
            catatAksiPanelVoice(guild.id, room, interaction.user, 'mereset pengaturan voice');
            await interaction.reply({ content: '✅ Pengaturan direset. Izin khusus anggota dan batas pengguna dikembalikan ke default.', ephemeral: true });
            return;
        }

        if (action === 'name') {
            if (!nilai || nilai.length > 100) {
                await interaction.reply({ content: 'Nama channel harus berisi 1–100 karakter.', ephemeral: true });
                return;
            }
            await room.setName(nilai);
            catatAksiPanelVoice(guild.id, room, interaction.user, `mengubah nama channel menjadi ${nilai}`);
            await interaction.reply({ content: `✅ Nama channel diubah menjadi **${nilai}**.`, ephemeral: true });
            return;
        }

        if (action === 'limit') {
            const jumlah = Number(nilai);
            if (!Number.isInteger(jumlah) || jumlah < 0 || jumlah > 99) {
                await interaction.reply({ content: 'Batas anggota harus 0–99 (0 berarti tanpa batas).', ephemeral: true });
                return;
            }
            await room.setUserLimit(jumlah);
            catatAksiPanelVoice(guild.id, room, interaction.user, `mengatur batas anggota menjadi ${jumlah || 'tanpa batas'}`);
            await interaction.reply({ content: `✅ Batas anggota diatur ke **${jumlah || 'tanpa batas'}**.`, ephemeral: true });
            return;
        }

        const targetId = nilai.match(/^<@!?(\d{17,20})>$/)?.[1] || ( /^\d{17,20}$/.test(nilai) ? nilai : null );
        if (!targetId) {
            await interaction.reply({ content: 'Masukkan mention atau ID anggota Discord yang valid.', ephemeral: true });
            return;
        }
        const target = await guild.members.fetch(targetId).catch(() => null);
        if (!target || target.user.bot || target.id === ownerId) {
            await interaction.reply({ content: 'Anggota tidak valid atau merupakan pemilik channel.', ephemeral: true });
            return;
        }

        if (action === 'transfer' && target.voice.channelId !== roomId) {
            await interaction.reply({ content: 'Anggota yang menerima kepemilikan harus sedang berada di room ini.', ephemeral: true });
            return;
        }

        if (action === 'kick') {
            if (target.voice.channelId !== roomId) {
                await interaction.reply({ content: 'Anggota tersebut tidak berada di room ini.', ephemeral: true });
                return;
            }
            await target.voice.disconnect('Dikeluarkan oleh pemilik voice sementara');
            await interaction.reply({ content: `👢 ${target.user.tag} dikeluarkan dari room.`, ephemeral: true });
            return;
        }

        if (action === 'trust' || action === 'invite' || action === 'untrust' || action === 'block' || action === 'unblock') {
            if (action === 'untrust' || action === 'unblock') {
                await room.permissionOverwrites.delete(target.id);
                await interaction.reply({ content: `✅ Izin khusus ${target.user.tag} dihapus.`, ephemeral: true });
                return;
            }
            await room.permissionOverwrites.edit(target.id, action === 'block'
                ? { ViewChannel: false, Connect: false }
                : { ViewChannel: true, Connect: true, Speak: true });
            await interaction.reply({
                content: action === 'block'
                    ? `⛔ ${target.user.tag} diblokir dari room.`
                    : `✅ ${target.user.tag} sekarang dapat melihat dan masuk ke room.`,
                ephemeral: true
            });
            return;
        }

        if (action === 'transfer') {
            await room.permissionOverwrites.edit(target.id, { ViewChannel: true, Connect: true, Speak: true });
            await room.permissionOverwrites.edit(ownerId, { ViewChannel: null, Connect: null, Speak: null });
            server.voice.rooms[roomId] = target.id;
            simpanOwoState();
            await interaction.reply({ content: `👑 Kepemilikan room dipindahkan ke ${target}.`, ephemeral: true });
            return;
        }

        await interaction.reply({ content: 'Aksi panel tidak dikenali.', ephemeral: true });
    } catch (error) {
        console.error(`Gagal menjalankan aksi panel voice ${action}:`, error);
        await interaction.reply({ content: '❌ Pengaturan gagal diterapkan. Pastikan bot memiliki izin yang dibutuhkan.', ephemeral: true }).catch(replyError => {
            console.error('Gagal mengirim respons error modal voice:', replyError);
        });
    }
});

client.on('guildMemberAdd', async member => {
    if (member.user.bot) return;
    const settings = ambilDataServer(member.guild.id).settings;
    if (settings.autoroleId) {
        const role = member.guild.roles.cache.get(settings.autoroleId);
        if (role) {
            try {
                await member.roles.add(role, 'Auto-role anggota baru');
            } catch (error) {
                console.error(`Gagal memberikan auto-role kepada ${member.user.tag}:`, error);
            }
        } else {
            console.error(`Role auto-role ${settings.autoroleId} tidak ditemukan di server ${member.guild.id}.`);
        }
    }
    if (settings.welcomeChannelId) {
        const channel = member.guild.channels.cache.get(settings.welcomeChannelId);
        if (channel?.isTextBased()) {
            try {
                await channel.send(await buatPesanMember(member, settings, 'welcome'));
            } catch (error) {
                console.error('Gagal mengirim pesan welcome:', error);
            }
        } else {
            console.error(`Channel welcome ${settings.welcomeChannelId} tidak tersedia di server ${member.guild.id}.`);
        }
    }
});

client.on('guildMemberRemove', async member => {
    if (member.user.bot) return;
    const settings = ambilDataServer(member.guild.id).settings;
    if (!settings.goodbyeChannelId) return;
    let channel;
    try {
        channel = await member.guild.channels.fetch(settings.goodbyeChannelId);
    } catch (error) {
        console.error(`Gagal mengambil channel goodbye ${settings.goodbyeChannelId} di server ${member.guild.id}:`, error);
        return;
    }
    if (!channel?.isTextBased() || typeof channel.send !== 'function') {
        console.error(`Channel goodbye ${settings.goodbyeChannelId} tidak tersedia di server ${member.guild.id}.`);
        return;
    }
    try {
        await channel.send(await buatPesanMember(member, settings, 'goodbye'));
    } catch (error) {
        console.error('Gagal mengirim pesan goodbye:', error);
    }
});

client.on('voiceStateUpdate', async (oldState, newState) => {
    let acquiredLockKey;
    try {
        const memberVoice = newState.member || oldState.member;
        const guild = newState.guild || oldState.guild;
        if (!guild) return;
        const serverVoice = ambilDataServer(guild.id);

        if (
            memberVoice &&
            !memberVoice.user.bot &&
            newState.channelId &&
            newState.channelId === serverVoice.voice.lobbyId &&
            oldState.channelId !== newState.channelId
        ) {
            const lockKey = `${guild.id}:${memberVoice.id}`;
            if (!voiceCreationLocks.has(lockKey)) {
                voiceCreationLocks.add(lockKey);
                acquiredLockKey = lockKey;
                let room;
                try {
                    const lobby = guild.channels.cache.get(serverVoice.voice.lobbyId);
                    if (!lobby || ![ChannelType.GuildVoice, ChannelType.GuildStageVoice].includes(lobby.type)) {
                        throw new Error(`Lobby voice ${serverVoice.voice.lobbyId} tidak ditemukan atau bukan voice channel.`);
                    }

                    room = await guild.channels.create({
                        name: `🔊 ${memberVoice.displayName}`.slice(0, 100),
                        type: ChannelType.GuildVoice,
                        parent: serverVoice.voice.categoryId || lobby.parentId || undefined,
                        permissionOverwrites: [
                            { id: guild.roles.everyone.id, allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.Connect] },
                            { id: memberVoice.id, allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.Connect, PermissionsBitField.Flags.Speak] }
                        ],
                        reason: `Voice sementara untuk ${memberVoice.user.tag}`
                    });
                    serverVoice.voice.rooms[room.id] = memberVoice.id;
                    simpanOwoState();
                    await memberVoice.voice.setChannel(room, 'Masuk ke voice sementara yang baru dibuat');
                } catch (error) {
                    console.error('Gagal membuat voice sementara:', error);
                    if (room) {
                        delete serverVoice.voice.rooms[room.id];
                        simpanOwoState();
                        await room.delete('Pembuatan voice sementara gagal').catch(deleteError => {
                            console.error('Gagal membersihkan voice yang tidak terpakai:', deleteError);
                        });
                    }
                    memberVoice.send('⚠️ Bot tidak bisa membuat atau memindahkanmu ke voice sementara. Periksa izin **Manage Channels** dan **Move Members** bot.').catch(dmError => {
                        console.error('Gagal memberi tahu anggota tentang kegagalan voice sementara:', dmError);
                    });
                }
                if (room) {
                    try {
                        await room.send({
                            content: `${memberVoice}, voice sementara milikmu sudah siap. Tombol panel hanya dapat digunakan oleh pemilik channel.`,
                            ...buatPanelVoice(room, memberVoice.id)
                        });
                    } catch (error) {
                        console.error('Gagal mengirim pesan sambutan voice sementara:', error);
                    }
                }
                voiceCreationLocks.delete(lockKey);
                acquiredLockKey = null;
            }
        }

        if (oldState.channelId && oldState.channelId !== newState.channelId && serverVoice.voice.rooms[oldState.channelId]) {
            const oldRoom = guild.channels.cache.get(oldState.channelId);
            if (oldRoom?.type === ChannelType.GuildVoice && oldRoom.members.size === 0) {
                try {
                    await oldRoom.delete('Voice sementara kosong');
                    delete serverVoice.voice.rooms[oldState.channelId];
                    simpanOwoState();
                } catch (error) {
                    console.error('Gagal menghapus voice sementara yang kosong:', error);
                }
            }
        }

        const member = newState.member || oldState.member;
        if (member?.user && !member.user.bot) {
            const voiceEvents = [];
            if (!oldState.channelId && newState.channelId) {
                voiceEvents.push({ channel: newState.channel, type: 'join' });
            } else if (oldState.channelId && !newState.channelId) {
                voiceEvents.push({ channel: oldState.channel, type: 'leave' });
            } else if (oldState.channelId && newState.channelId && oldState.channelId !== newState.channelId) {
                voiceEvents.push(
                    { channel: oldState.channel, type: 'leave' },
                    { channel: newState.channel, type: 'join' }
                );
            }

            for (const { channel, type } of voiceEvents) {
                if (!channel || typeof channel.send !== 'function') continue;
                try {
                    await channel.send({
                        embeds: [buatEmbedLogVoice(member, type)],
                        allowedMentions: { users: [member.id] }
                    });
                } catch (error) {
                    console.error(`Gagal mengirim log ${type} voice ke chat channel ${channel.id}:`, error);
                }
            }
        }

    } catch (error) {
        if (acquiredLockKey) voiceCreationLocks.delete(acquiredLockKey);
        console.error('Gagal memproses perubahan status voice:', error);
    }
});

client.on('channelDelete', channel => {
    if (!channel.guild) return;
    const serverVoice = ambilDataServer(channel.guild.id);
    let berubah = false;
    if (serverVoice.voice.rooms[channel.id]) {
        delete serverVoice.voice.rooms[channel.id];
        berubah = true;
    }
    if (serverVoice.voice.lobbyId === channel.id) {
        delete serverVoice.voice.lobbyId;
        delete serverVoice.voice.categoryId;
        berubah = true;
    }
    if (berubah) simpanOwoState();
});

client.login(process.env.TOKEN);